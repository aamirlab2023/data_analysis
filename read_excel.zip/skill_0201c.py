import pandas as pd

# Load data from csv file
df = pd.read_excel("../datasets/full_data.xlsx", sheet_name=0, header=0)

# Display the dataframe
print(df)
# Display the first few rows of the dataframe
print(df.head())
# Display the last few rows of the dataframe
print(df.tail())
# Display the data types of each column
print(df.dtypes)
# Display the number of rows and columns in the dataframe
print(df.shape)
# Display the column names of the dataframe
print(df.columns)
# Display the number of missing values in each column
print(df.isnull().sum())
# Display the number of unique values in each column
print(df.nunique())
# Display the summary statistics of the dataframe
print(df.describe())
# Display the first 3 rows of the dataframe
print(df.head(3))
# Display the last 3 rows of the dataframe
print(df.tail(3))