# Pivoting and Unpivoting Data

## Introduction

- **Pivoting:** Transforming data from a long (vertical) format to a wide (horizontal) format by turning unique values from one column into multiple columns.

- **Example:** Turning months into columns for each product’s sales.

- **Unpivoting:** The opposite process – transforming wide data into a long format.

- **Example:** Turning multiple monthly columns back into two columns: Month and Value.

## The Why Section

- Pivoting helps summarize and analyze data more easily by grouping and aggregating.

- Unpivoting is useful for data normalization, especially when preparing data for tools like Power BI, Excel PivotTables, or databases.

## Advantages

- Makes data analysis more flexible and insightful.

- Allows creation of reports and dashboards.

- Prepares raw datasets for effective visualization or deeper analysis.

- Unpivoted data is easier to maintain and automate.

## Practical

### (a) Normal Excel Way

**Pivoting with PivotTables:**

1. Select your dataset.

2. Click **Insert > PivotTable**.

3. Choose location and click **OK**.

4. In PivotTable Fields:

    - Drag items into **Rows**, **Columns**, and **Values**.

    - Excel will pivot the data accordingly.

**Unpivoting (manual workaround):**

- No direct unpivot tool in basic Excel.

- Use Power Query or formulas like INDEX, MATCH, or FILTER.

### (b) Power Query Way (More flexible)

**Pivoting:**

1. Select your data > **Data > From Table/Range**.

2. In Power Query, select the column to pivot.

3. Go to **Transform > Pivot Column**.

4. Choose the value column and aggregation method.

5. Click **Close & Load**.

**Unpivoting:**

1. Select your data > **Data > From Table/Range**.

2. Select columns to unpivot (usually multiple columns).

3. Go to **Transform > Unpivot Columns**.

4. Click **Close & Load**.

## Examples

### Pivoting Examples

### Example 1: Sales by Product and Month

|Product | Month | Sales |
|:-----|:-----|:-----|
|A | Jan | 100 |
|A | Feb | 120 |
|B | Jan | 90 |

### → Pivoted:

|Product | Jan | Feb |
|:-----|:-----|:-----|
|A | 100 | 120 |
|B | 90 | |	

### Example 2: Attendance by Student and Subject

|Name | Subject | Attendance |
|:-----|:-----|:-----|
|Alice | Math | 90% |
|Alice | Science | 85% |

### → Pivoted:

|Name | Math | Science |
|:-----|:-----|:-----|
|Alice | 90% | 85% |

### Unpivoting Examples

### Example 1: Monthly Sales Data

|Product | Jan | Feb | Mar |
|:-----|:-----|:-----|:-----|
|A | 100 | 120 | 130 |

### → Unpivoted:

|Product | Month | Sales |
|:-----|:-----|:-----|
|A | Jan | 100 |
|A | Feb | 120 |
|A | Mar | 130 |

### Example 2: Student Grades

|Name | Math | Science | History |
|:-----|:-----|:-----|:-----| 
|Bob | 80 | 85 | 78 |

### → Unpivoted:

|Name | Subject | Grade |
|:-----|:-----|:-----|
|Bob | Math | 80 |
|Bob | Science | 85 |
|Bob |History | 78 |

## Summary of the Skill

Pivoting and Unpivoting are essential Excel skills for reshaping data:

- Pivoting organizes long-format data into a summarized table format for reporting.

- Unpivoting transforms wide-format data into a normalized form for better analysis and compatibility with data tools.

- Power Query makes both processes user-friendly and efficient.

## Exercises

### Exercise 1: Pivoting

- **Dataset:** Employee, Department, Salary

- **Pivot:** Show total salary by Department.

### Exercise 2: Unpivoting

- **Dataset:** Product with columns Jan, Feb, Mar sales

- **Unpivot:** Convert into Product, Month, Sales format.

### Exercise 3: Pivot with Aggregation

- **Dataset:** Salesperson, Region, Sales

- **Pivot:** Total sales by Region and Salesperson.
