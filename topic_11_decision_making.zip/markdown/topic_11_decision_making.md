> # Python for Data Analysis
> # Decision Making
> # Dr. Aamir Alaud Din
> # June 25, 2025

> ## Outline

**1. Recap**

**2. Objectives**

**3. The Why Section**

**4. Introduction**

**5. Algorithmic Flowchart and Pseudocode**

**6. Program**

**7. Summary**

> ## Recap

- A program in which a block of code is to be executed several times and the number of times of repetition is unknown and linked to the fulfillment of a condition is known as the conditional loop or a `while`loop.

- There might be a part of the program before entering the loop.

- The conditional loop starts with the keyword `while`.

- The conditional statement is a logical statement which might be a single or compound logical statement.

- The loop condition terminates at the colon `:`.

- The lines of code which have to be repeated must be indented by a tab stop.

- The indented lines are called the body of `while` loop.

- The indented lines of code keep on executing unless the logical statement evaluates to `FALSE`.

- The test condition variable must be updated within the body of the loop, else the loop will keep on repeating infinitely.

- There may be a part of program after the body of the loop and it must be at the indentation level before the start of body of the loop.

> ## Objectives

After taking this lecture and studying, you should be able to:

- Understand the link of human life decision making with decision making in computer programming.

- To understand decision making in Python with the aid of flowchart and pseudocode.

- To write Python programs to implement decision making.

> ## The Why Section

- In our everyday life, we take a lot of decisions.

- The decisions are linked to the fulfillment of one or several conditions.

- An example of decision making is to decide the route from home to university and back.

- This decision involves the conditions of travel time, mileage of car, and traffic conditions etc.

- Another example is to choose the location for home construction.

- This decision making also involves several conditions like ease of access to markets, travelling to office and other locations, security, and many others.

- The question is, &ldquo;is decision making possible in Python programming?&rdquo;

- If yes, how?

- How to **understand** the selection of decision making conditions in Python?

- How to **use** the decision conditions in Python programs?

- We answer to all these question in the ongoing discussion.

> ## Introduction

- As discussed above, we want to understand the decision making in Python.

- We also discussed that, decision making is linked to decision condition(s).

- During decision making, we have to select a final decision from a choice of decisions.

- For example, for the selection of route from home to university, we have different conditions like 1) Traffic Congestion, 2) Longest Travel Duration, and 3) Car Mileage etc.

- We can start our journey with any preferred condition.

- We may also choose multiple conditions for decision making.

- Same is the case in Python that .

- We have to check whether a number is divisible by 2, or 3, or by any other number?

- In order to understand the complete structure, we divide this problem into three problems which cover all the constructs of decision making statements in python.

- These structures are given below.

### 1) Single Decision (`if`) Statement

- We have to check whether the input number is divisble by 2?

### 2) Multiple Decisions (`if` and `elif`) Statement

- We check whether the number is divisible by 2 or not?

### 3) Multiple and Default Decisions (`if`, `elif`, and `else`) Statement

- We want to check wheter the number is divisible by 2, and if not, is it divisible by 3, and if still not, it is definitely divisible by some other number (at least by itself).

- Now we discuss the algorithm and code of this example.

> ## Algorithmic Flowchart and Pseudocode

### 1) Single Decision (`if`) Statement

#### a) Flowchart

![single](../images/01.png)

***Figure 1.*** General algorithmic flowchart for decision making.

#### b) Pseudocode

- The pseudocode for the problem quoted above is as below.

```
DISPLAY 'Enter a number: '
INPUT number
IF number % 2 == 0 THEN
    DISPLAY 'The number ', number, ' is divisible by 2.'
```

### 2) Multiple Decisions (`if` and `elif`) Statement

#### a) Flowchart

![multiple](../images/02.png)

***Figure 3.*** Multiple decision understanding in computer programming.

#### b) Pseudocode

```
DISPLAY 'Enter a number: '
INPUT number
IF number % 2 == 0 THEN
    DISPLAY 'The number ', number, ' is divisible by 2.'
ELSE IF number % 3 == 0 THEN
    DISPLAY 'The number ', number, ' is divisible by 3.'
```

### 3) Multiple and Default Decisions (`if`, `elif`, and `else`) Statement

#### a) Flowchart

![default](../images/03.png)

***Figure 3.*** General flowchart for multiple decisions with a default statement.

#### b) Pseudocode

```
DISPLAY 'Enter a number: '
INPUT number
IF number % 2 == 0 THEN
    DISPLAY 'The number ', number, ' is divisible by 2.'
ELSE IF number % 3 == 0 THEN
    DISPLAY 'The number ', number, ' is divisible by 3.'
ELSE
    DISPLAY 'The number ', number, ' is divisible by some other number.'
```

> ## Program

- Now we are in a position to write Python programs for the above three decision making statements.

### 1) Single Decision (`if`) Statement

```python
number = int(input("Enter a number: "))

if number % 2 == 0:
    print(f"The number {number:d} is divisible by 2.")
```

### 2) Multiple Decisions (`if` and `elif`) Statement

```python
number = int(input("Enter a number: "))

if number % 2 == 0:
    print(f"The number {number:d} is divisible by 2.")

elif number % 3 == 0:
    print(f"The number {number:d} is divisible by 3.")
```

### 3) Multiple and Default Decisions (`if`, `elif`, and `else`) Statement

```python
number = int(input("Enter a number: "))

if number % 2 == 0:
    print(f"The number {number:d} is divisible by 2.")

elif number % 3 == 0:
    print(f"The number {number:d} is divisible by 3.")

else:
    print(f"The number {number:d} is divisible by some other number.")
```

> ## Summary

- In computer programming and Python programming, decision making is possible.

- Decision making statements always involve a decision condition.

- The decision making statement may be classified as single decision, multiple decisions, and multiple decisions with a default block.

> ## Exercises

### Exercise 1

Write a Python program which accepts a day number from user according to the following table and outputs the name of the day.

|Day Number | Name of the Day |
|:-----|:-----|
|1 | Sunday |
|2 | Monday |
|3 | Tuesday |
|4 | Wednesday |
|5 | Thursdday |
|6 | Friday |
|7 | Saturday |

### Exercise 2

Write a python program which takes accepts score as input from user and prints student grades according to following table.

|Score | Grade |
|:-----|:-----|
|Less Than 40 | F |
|Less Than 50 | D |
|Less Than 60 | C |
|Less Than 70 | B |
|Less Than 80 | B+ |
|Less Than 90 | A |
|Less Than or Equal to 100 | A+ |