> # Data Analysis with Python
> # Simple Programs, Comments, Documentation, and License
> # Dr. Aamir Alaud Din

> # Outline

## 1. Recap
## 2. Objectives
## 3. The Why Section
## 4. Simple Python Programs
## 5. Comments and Documentation
## 6. License
## 7. Summary
## 8. Exercises

> # Recap

- A function is a reusable Python program which may require no to several inputs.

- A Python package is a collection of functions which can be utilized to accomplish a given computation/task.

- Python functions/methods and attributes do something needful for the user but functions/methods require paranthesis with no to several inputs while attributes don't require paranthesis and input.

- Python packages can be imported with and without names.

- If a package is called without name, the name of package dot the function is used to call the function from the package.

- If a package is imported with name, the name dot function can be used to call and use a function from the package.

- The specific functions from a given package can be called with and without names separated by commas.

- All functions from a package can be called from a package by a `*` symbol.

- In order to keep track of the functions and package used, it is recommened to call packages by name.

- String and list methods allow user to accomplish several useful tasks.

- It is highly recommended to import and use random and statistics packages to accomplish some tasks/computations.

> # Objectives

After taking this lecture and studying, you should be able to:

- Describe an algorithm in your own words and develop algorithms to write Python programs.

- Write simple Python programs to perform a computation.

- Know how to debug a Python program and the best tools of debugging.

- Describe in your own words the importance of comments in computer programming and use comments in your programs.

- Describe in your own words the importance of documentation and prepare document/help of your programs.

- Describe in your own words the importance of license of computer programs.

- Know common functions used frequently in Python programming.

> # The Why Section

- Developing a successful Python program is not a simple task.

- It invovles three major steps which are (1) development of algorithm, (2) writing the program itself, and (3) debugging the program.

- The most important step is the development of a successful and working algorithm.

- An algorithm is a thought which involves a detailed working on defining all the required variables from start to end of the program, the program structure, program hierarchy including a detailed step by step working to accomplish the computation successfully.

- It is a good idea to write down the algorithm on a paper so that if any step is lost from your mind, you have a copy of the algorithm to develop the program.

- You might think that we have to write a computer program, then why is there need to think the algorithm and also write down it on a paper?

- The second step is the development of the program which is of course the final destination, but it has less importance than thinking of the algorithm and debugging.

- For you and those who are new to computer programming, writing a working computer program may be difficult because the command and functions are not at your hand.

- Then, how to write a computer program without having all the commands and functions at hand?

- Finally, the second most important step is the debugging of the program.

- All the computer programming geeks, even the Linus Torvalds, Richard Stallman, and Dennis Ritchie have/had to face bugs in their programs.

- Bugs are the errors in the computer programs and think them as your fate, and everyone does face them.

- Sometimes, removing the bugs takes several hours to several days specially those which don't arise due to syntax but due to logical errors in the prgram.

- When bugs are the fate, and we have to write successful working programs, then how to remove errors (debugging)?

- It is a well known fact that if a computer program is opened after a long time for some modification, the programmers forget which variables describe what and also forget the steps to accomplish the task/computation.

- If a computation is performed, we don't know the associated units with each variable and modification/extension of program becomes difficult.

- Then, how can we remember the variables, associated units, and the algorithm of the program?

- For every machine, user manual is necessary to know how to use the machine.

- We also see user's manual for many software packages on how to use the software.

- How can we write the documentation/help/user's manual of our programs and how to see the documentation of a program written by someone else?

- What are different software licenses and how to incorporate license in your own programs?

- In writing Python programs, only few functions are there which are very important as they are used extensively in the programs.

- Which common functions are important?

- We answer to all these questions shortly.

![RichardStallman](../images/0902.png)

***Figure 1.*** Richard Stallman &mdash; Founder of Free Software Foundation (FSF) and developer of LISP, Emacs, and GNU tools.

![LinusTorvalds](../images/0903.webp)

***Figure 2.*** Linus Torvalds &mdash; Creator of Linux Operating System and Github.

![DennisRitchie](../images/0901.png)

***Figure 3.*** Dennis Ritchie &mdash; Father of C language and Co-Founder of Unix Operating System.

> # Simple Python Programs

To develop large Python programs/projects, the steps of 1) writing algorithms/flowcharts, 2) developing pseudocodes, 3) developing Python programs, and 4) Debugging of the program are followed. We discuss them one by one.

## a) Algorithms

- Use Nikola Tesla's strategy for successful completion of the project.

![NikolaTesla](../images/0904.png)

***Figure 4.*** Nikola Tesla &mdash; Famous for his successful experiments at first run.

- It is famous about Nikola Tesla that 95-98% of his experiments were always successful.

- The reason of success was his thought process of performing virtual experiments over and over and when realized no problem in experiments after several successful virtual runs, he used to perform experiments.

- Same is the case with computer programs.

- Think on all the required variables, all the commands on each and every step of the program, and keeping all the steps in a running order (one successful command after the other) and write down algorithm on paper.

- This strategy leads to writing of successful programs with least bugs.

- Now, let's develop an algorithmic flowchart for calculation of break-even point (units).

- The formula to calculate break-even point is:

\[
\text{Break-Even Point} = \frac{\text{Fixed Costs}}{\text{Selling Price per Unit}-\text{Variable Cost per Unit}}    
\]

- Before developing algorithm, we understand the terminologies.

> ### Fixed Costs
> Fixed costs are expenses that do not change regardless of how many units are produced or sold.

### Examples

- Rent

- Salaries of permanent staff

- Insurance

- Depreciation

- Equipment lease payments
  
### Key Point

- Even if you sell zero units, you still pay fixed costs.

> ### Variable Costs per Unit
> Variable cost per unit is the cost that changes directly with each additional unit produced or sold.

### Examples

- Raw materials

- Direct labor (paid per item)

- Packaging

- Shipping (per item)

### Key Point

- If you produce no units, variable cost is zero. If you produce more, total variable cost increases.

### Example

- Suppose you run a T-shirt business:
  
| Type | Description | Cost |
|:-----|:-----|:-----|
|Fixed Cost | Rent and salaries | $5,000/month |
|Variable Cost | Fabric, printing, packaging per shirt | $8/shirt |

- If you produce 100 shirts:

    - Total fixed cost = $5,000

    - Total variable cost = 100 × $8 = $800

    - Total cost = $5,800

- We use the following example to calculate the break-even point (units).

> ## Example
> Calculate the break-even point for the following data.
> - Fixed Costs = $20,000
> - Selling Price per Unit = $50
> - Variable Cost per Unit = $30

- The algorithmic flowchart for the above example is shown below.

![Flowchart](../images/0905.png)

***Figure 5.*** Algorithmic flowchart for calculation of break-even point.

## b) Pseudocode

- The pseudocode for the task is shown below.

```
INPUT fixed_cost = 20000
INPUT sell_price = 50
INPUT var_cost = 30

CALCULATE break_even

DISPLAY break_even
```

## c) Program

- The python program to calculate the break-even point is given below.
  
```python
fixed_cost = 20000
sell_price = 50
var_cost = 30

break_even = fixed_cost / (sell_price - var_cost)

print(f"The break-even point is: {break_even:d} units")
```

## d) Debugging

- As discussed previously, think bugs in the programs as fate of a programmer.

- Instead of being in the panic state, develop curiosity in removing the bugs and this curiosity will lead to enjoying the debugging phase.

- There are not very strong debugging tools to debug a python program.

- The `print` function itself is a powerful debugger.

- In case of bugs, try printing every line/output of the program to find bugs.

- The `print` function is a too much powerful debugger that it also helps to debug the non syntax bugs.

> # Comments and Documentation

## a) Comments

- For newbies in computer programming, writing computer programs is difficult and time consuming step.

- However, the most time consuming steps are development of algorithm and debugging of the program.

- Once developed successfully, there is always room for improvement in the programs, a reason of newer versions of software and updates.

- When the program files are opened for improvement or modification, the programmers forget the reasons of defining several variables and the steps adopted to write the program.

- A good program always contains comments in the programs which describe why variables were defined and also contain brief description of major steps of the program.

- The comments in python start with `#` symbol.

- Comment lines are always ignored by python and they are for programmer's reference only.

- Comments are ignored by python, but they remind the programmer about the variables and major steps.

- The above program with comments can be written as follows.

```python
fixed_cost = 20000 # Fixed cost in dollars
sell_price = 50 # Sell price per unit in dollars
var_cost = 30 # Variable cost per unit in dollars

# Calculate break even point and print it
break_even = fixed_cost / (sell_price - var_cost)

print(f"The break-even point is: {break_even:d} units")
```

## b) Documentation

- Every python program must be well documented before being released for the users.

- The documentation is written within tripple quotes which displays the documentation as it is written by the developer.

- The program starts with documentation and the code is written after the documentation.

- For functions, the documentation is written just after the function definition.

- The documentaion of a package/function can be called by invoking the following command.

```python
import program_name
help(program_name)
```

- An example program with documentation is available for your reference.

> # License

- Any computer program or application is developed with a target.

- The companies hire personnel to develop an application and their salaries and profit is linked to software license.

- Some licenses, specially proprietary software, are paid and the user has to pay the license fee to use the software.

- There are also free licenses, specially in academia.

- One of the most popular software license is GNU General Public License (GPL) according to which users can use the software free of cost.

- Some other free licenses include Open Source License, MIT license, and Free BSD license etc.

- Some programmers include the short license, an example is shown below.

```python
"""
    break_even.py - This program contains function break_even to
    calculate the break even point of the business.

    Copyright (C) 2025 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

    Syntax: break_even.py
"""
```

> # Summary

- Use Nikol Tesla's strategy to develop algorithms.

- Developing algorithm and pseudocode reduces the chances of bugs in the programs.

- Write python programs and follow some standard of writing as it will help you if you encounter your own program after a long time.

- Majority of the programs have bugs after first draft of code.

- Develop curiosity in debugging so that you play with bugs, enjoy debugging, and remin comfortable with them.

- Printing of every line/output is a powerful debugging method which also has a high probability of catching even the non syntax bugs.

- Comments are very useful in python programs as they remind us different things when the code is reopened after a long time for modification or upgradation.

- Comments start with the `#` symbol and are ignored by python interpreter as they are for programmer's reference only.

- Comments spanning several lines are enclosed within tripple quotes and they appear as they are typed in the text editor.

- Every python program, which has to be released for the users, must contain the program documentation.

- Documentation is incorporated at the start of a program and just after the function definition lines.

- If it is required to float a program to the community, it is necessary to incorporate the license so that users use the program as per the license sections.

> # Exercises

## Exercise 1

Write a python program to calculate the total revenue of a service business with service rate of $\$25/hr$ and $40\text{ }hours$ of work using the following formula.
$$
\text{Total Revenue} = \text{Rate per Hour} \times \text{Total Hours Worked}
$$

## Exercise 2

The net profit in a business is given by the following formula.
$$
\text{Net Profit} = \text{Total Revenue} - \text{Total Expenses}
$$
Write a python program to compute the net profit of a business having a revenue of $\$1000$ and $\$200$ of expenses.

## Exercise 3

The effective hourly rate in a business is calculated using the following formula.
$$
\text{Effective Hourly Rate} = \frac{\text{Net Profit}}{\text{Total Hours Worked}}
$$
If the net profit of a business is $\$800$ and total hours of work are $\$40\text{ }hours$, write a python program to calculate the effective hourly rate.
