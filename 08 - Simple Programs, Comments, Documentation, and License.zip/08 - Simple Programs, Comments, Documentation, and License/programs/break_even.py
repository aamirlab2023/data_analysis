"""
    break_even.py - This program contains function break_even to
    calculate the break even point of the business.

    Copyright (C) 2025 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

    Syntax: break_even.py
"""

fixed_cost = float(input("Enter the fixed cost: "))
sell_price = float(input("Enter the sell price per unit: "))
var_cost = float(input("Enter the variable cost per unit: "))

break_even = fixed_cost / (sell_price - var_cost)

print(f"The break-even point is: {break_even:.2f} units")
