# Converting Data Ranges into Excel Tables

## Introduction

Converting a data range into an Excel Table means transforming a simple block of data (rows and columns) into a dynamic, structured format recognized by Excel as a "Table object". This enables features like automatic filtering, styling, structured references, and easier data analysis.

## The Why Section

- To apply Excel's built-in Table tools for formatting and analysis.

- To make data ranges dynamic and auto-expand with new entries.

- To simplify referencing in formulas and charts.

## Advantages

|Feature | Benefit |
|:-----|:-----|
|Auto Formatting | Professionally styled headers and rows |
|Auto Expansion | Automatically includes new rows/columns in the Table |
|Filtering & Sorting | Enabled by default with dropdowns |
|Structured References | Use column names instead of cell ranges in formulas |
|Easier Pivot Tables | Tables work seamlessly as Pivot Table sources |
|Total Row | Easy summary statistics (Sum, Average, Count, etc.) |

## Practical

### (a) Normal Excel Way

1. Select the data range.

2. Go to the **Insert** tab → click **Table**.

3. Check "**My table has headers**" if your data includes headers.

4. Click **OK**.

_**Alternative:**_ Use keyboard shortcut **Ctrl + T**.

### (b) Power Query Way

1. Select the data range.

2. Go to **Data → click From Table/Range**.

3. Power Query automatically converts it to a table.

4. Click **Close & Load** to bring it back as a Table.

## Examples

### Example 1: Sales Data Table

Convert a list of sales records (Date, Customer, Amount) into a Table to enable sorting/filtering.

### Example 2: Product Inventory Table

Convert a range (Product, Category, Stock, Price) into a Table for automatic formula references.

## Summary

Converting data ranges into Excel Tables enhances usability by turning static ranges into dynamic, interactive structures. Tables support built-in filtering, formatting, and automatic data handling features. This is essential for efficient data analysis, reporting, and automation in Excel.

## Exercises

### Exercise 1
Convert a dataset (Employees, Departments, Salaries) into an Excel Table and apply a table style.

### Exercise 2
Add 5 new rows to the Table and verify that the Table auto-expands.

### Exercise 3
Use Power Query to load a dataset and return it as an Excel Table.
