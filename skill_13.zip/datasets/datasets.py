import pandas as pd
import random

def generate_sales_data():
    customers = ['Alice', 'Bob', 'Charlie', 'Diana', 'Edward']
    data = {
        'Date': pd.date_range(start='2024-01-01', periods=20, freq='D'),
        'Customer': [random.choice(customers) for _ in range(20)],
        'Amount': [round(random.uniform(100, 1000), 2) for _ in range(20)]
    }
    df = pd.DataFrame(data)
    df.to_excel("sales_data_table.xlsx", index=False)

def generate_inventory_data():
    products = [f"Product_{i}" for i in range(1, 21)]
    categories = ['Electronics', 'Clothing', 'Food', 'Books']
    data = {
        'Product': products,
        'Category': [random.choice(categories) for _ in products],
        'Stock': [random.randint(10, 200) for _ in products],
        'Price': [round(random.uniform(5, 500), 2) for _ in products]
    }
    df = pd.DataFrame(data)
    df.to_excel("inventory_data_table.xlsx", index=False)

def generate_employee_data():
    names = [f"Employee_{i}" for i in range(1, 16)]
    departments = ['HR', 'Finance', 'IT', 'Marketing']
    data = {
        'Employee': names,
        'Department': [random.choice(departments) for _ in names],
        'Salary': [random.randint(40000, 100000) for _ in names]
    }
    df = pd.DataFrame(data)
    df.to_excel("employee_data_table.xlsx", index=False)

if __name__ == "__main__":
    generate_sales_data()
    generate_inventory_data()
    generate_employee_data()
    print("Excel Table datasets generated.")
