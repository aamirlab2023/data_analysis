# Introduction to Python Programming

## Objectives

1. Describe in your own words what are computers and why are they used in computations.

2. Describe in your own words the computer user interaction.

3. Describe in your own words the scope and importance of python programming.

## The Why Section

- When we use computers for computation, we provide formulas to computers.

- We can also perform computations on paper using the formulas.

- Then, why do we use computers for computational tasks?

- Computers know only binary language (0's and 1's only).

- Then, how human computer interaction occurs?

- There are many other scientific programming languages like MATLAB, Octave, Scilab, Julia, Fortran, Mathematica, and Maple etc.

- Python is not a scientific programming language, but a general purpose programming language.

- Then, why are we studying python?

- We will answer these questions in the forthcoming discussion.

- We will start from very basics the -- definition of computer.

## Computers and Computations

> A computer is a universal machine that can do any computation you want it to do.
> -- Dr. Richard Stallman
			
![Computer](./images/0101.jpeg)
***Figure 1.*** A computer with its components.

> ### Example
> A car is moving with a speed of $120\;km/h$. How long will it take to cover a distance of $378\;km$ (distance between Islamabad and Lahore)?

- The example shown above is an example of computation.

- Any problem involving mathematical computations (at least with the use of binary operations) is a computational problem.

- Such problems can be solved easily by hand.

- The problem shown above can be solved as shown below.

> ### Solution
> $$
v = 120\;km/h
$$
$$
s = 378\;km 
$$
$$
t = ? (h)
$$
We know that,
$$
s = vt 
$$
Therefore, we have
$$
t = \frac{s}{v} = \frac{378\;km}{120\;kh/h} = 3.15\;h
$$

- When a computation can be performed by hand, then why do we use computers in computations?

- There are several reasons of using computers in computations, however, we describe only few here.

- These reasons are sufficient to establish that computers are very important in computations.

### 1. Speed/Efficiency

- Let's race in writing a table of 2 from 1 through 5000.

- I bet, writing the table by hand can never be faster than writing using computers.

- [Race](./programs/efficiency.py)

### 2. Complex Computations

- Compute the determinant of the matrix 

$$
\begin{bmatrix}
	-2 & 7 & 0 & 6 & -2 \\
	1 & -1 & 3 & 2 & 2 \\
	3 & 4 & 0 & 5 & 3 \\
	2 & 5 & -4 & -2 & 2 \\
	0 & 3 & -1 & 1 & -4 \\
\end{bmatrix}
$$

- The computation of the determinant of the above $5 \times 5$ matrix is a complex computation.

- To see this computation by hand [click here](https://semath.info/src/determinant-five-by-five.html).

- This computation is extremely simple with a [python program](./programs/determinant.py).

### 3. Generalization

- A good computer programmer writes a generalized computer programs.

- In the example of generating a table of 2 from 1 through 5000, the generalized program will allow the user to generate any table.

- Other generalization are the control of the user on starting and stopping points as given in [this program](./programs/generalize.py).

- A good computer program allows the user to get maximum benefit from the program and such programs are called generalized programs.

- For example, you can compute determinant of any matrix with the same program.

## Computer Programming

- Binary language, which is the language of 0s and 1s is the language of computers.

![Binary](./images/0102.jpg)

***Figure 2.*** Binary language (language of 0s and 1s) -- the language of computers.

- The computers are the most dumb machines in the world as the completely rely on the instructions (program as alphanumeric and special characters) to do something for the user and computers know only 0s and 1s.

- Now, the question is, how human-computer interaction occurs?

- In other words, how to pass on instructions to the computers to do something for the user?

- We try to understand this situation with the help of an example.

![Failure 1](./images/0103.png)

***Figure 3.*** Failure of a business deal due to communication gap.

![Success 1](./images/0104.png)

***Figure 4.*** Success of a business deal with the help of a translator.

![Failure 2](./images/0105.png)

***Figure 5.*** A user can't communicate with a computer due to lack of understanding the machine codeg which is hard to understand.

![Success 2](./images/0106.png)

***Figure 6.*** Python (translator) can help in user and computer interaction.

- Now, we know that python is a translator which translates the user's instruction (program) to the binary for the computer and vice versa.

- Still, there is a missing link.

### Filling the gap -- missing link

![Python Program](./images/0107.png)

***Figure 7.*** Snapshot of a Python program.

- The above program is a python program but not python itself.

- What is python, then?

- Python is what we download from Python's website and install in computer/laptop.

- Python converts python code to binary for computer and vice versa making human-computer interaction possible.

- Python program is just a text file which is human readable/writeable.

- Python understands only python programs and not other programs e.g., a C++ program.

- The only gap in our interaction with the computer is to learn how to write a python program so that we are able to instruct the computer to do some computation.

- The conversion of instruction to machine (binary) code for the computer and machine code to human readable format is the job of python.

![Filling the Gap](./images/0108.png)

***Figure 8.*** User-Computer interaction clarifying that we need to learn python programming to interact with computers.

## Python Programming

- We have established that we need to learn computer programming.

> ### Computer Programming
> Computer programming is the art of interacting with the computers to instruct the computers to perform a given computation.

- We will learn python programming to perform the computations.

- Being in the domain of data analysis, we will be interested in the programs relevant to data analysis as well as general and scientific problems.

![Rossum](./images/0109.jpg)

***Figure 10.*** Guido van Rossum -- the developer of Python programming language.

- Python programming language was written by Guido Van Rossum in 1991.

- Python is a general purpose programming language.

- Python had been among the top five programming languages for the past several years.

- Currently, python is the most popular programming language in the world.

- Currently, python version 3.12 is in use.

- Python is the most famous programming language in the world, [click here](https://www.tiobe.com/tiobe-index/) to see the rating.

![Top](./images/0110.png)

***Figure 10.*** Top ten programming languages based on number of hits per day.

### Scope and Applications of Python Programming Language

![Scope](./images/0111.png)

***Figure 11.*** Scope and applications of Python programming language.

![Scientific Computing](./images/0112.png)

***Figure 12.*** Scientific computing with Python.

## Summary

- Computers, because of their efficiency, performing complex computations, and generalization of programs are used in scientific computation.

- Computer programming converts human understandable code to machine code for the computers and machine code to human readable format for user.

- Python program is a collection of instructions in the form of alphanumeric characters while python is the software installed in your computer to convert python program to machine code.

- Since machine code is hard to code, so we need to learn python programming and write instructions for the computers in a python program and hand it over to python for the rest of the job.

- Python is encompassing the most important parts of data, science, engineering, and IT, therefore, is an important programming language.
