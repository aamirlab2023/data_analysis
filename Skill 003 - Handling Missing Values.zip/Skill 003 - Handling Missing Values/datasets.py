import pandas as pd
import numpy as np

# Example 1: Replace with mean/median/mode
df_scores = pd.DataFrame({
    'ID': [1, 2, 3, 4, 5],
    'Score': [80, np.nan, 75, np.nan, 90]
})
df_scores.to_csv("scores_missing.csv", index=False)

# Example 2: Delete Rows/Columns
df_people = pd.DataFrame({
    'Name': ['John', 'Ann', 'Mike'],
    'Age': [25, np.nan, 30],
    'Email': ['john@email.com', 'ann@email.com', np.nan]
})
df_people.to_csv("people_missing.csv", index=False)

# Exercise 1
scores_ex = pd.DataFrame({
    'Student_ID': range(1, 11),
    'Score': [88, 75, 92, np.nan, 67, 85, 90, np.nan, 76, 80]
})
scores_ex.to_csv("exercise_mean.csv", index=False)

# Exercise 2
fruits_ex = pd.DataFrame({
    'Fruit': ['Apple', 'Banana', np.nan, 'Apple', 'Orange', np.nan, 'Banana', 'Banana']
})
fruits_ex.to_csv("exercise_mode.csv", index=False)

# Exercise 3
people_ex = pd.DataFrame({
    'Name': ['Ali', 'Sara', 'Tom', 'Zara', 'Usman'],
    'Age': [24, np.nan, 29, 32, np.nan],
    'Email': ['ali@email.com', 'sara@email.com', np.nan, 'zara@email.com', 'usman@email.com']
})
people_ex.to_csv("exercise_delete.csv", index=False)
