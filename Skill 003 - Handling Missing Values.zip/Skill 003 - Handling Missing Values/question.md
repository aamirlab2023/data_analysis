For the Microsoft Excel skill titled "Handling Missing Values" with following sub-skills
- Replace with Mean/Median/Mode
- Remove Rows/Columns
Explain in detail
1. What is handling of missing values and what are the methods of handling missing values?
2. Why to handle missing values and which methods to use for specialized cases?
3. What are the advantages of handling missing values?
4. How to handle missing values (which buttons to click to complete the task) using Microsoft Excel in (a) normal way and (b) Power Querry way?
5. Give two examples of handling missing values by (a) replacing with mean/median/mode and (b) deleting rows/columns.
6. Give me summary of the skill
7. Give me three exercises to practice.
8. Also give me the python file to generate the data sets required for the examples and exercises.
