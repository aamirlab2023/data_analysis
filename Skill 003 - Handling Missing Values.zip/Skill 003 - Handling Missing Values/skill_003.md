# Handling Missing Values

This Microsoft Excel skill is on "Handling Missing Values", based on the following sub-skills:
- Replace with Mean/Median/Mode  
- Remove Rows/Columns.

## What Is Handling of Missing Values?
Missing values in a dataset refer to cells where data is not recorded. They can occur due to errors in data collection, transmission, or entry.

### Common Methods of Handling Missing Values:

- **Replace with Mean/Median/Mode:** Suitable for numerical or categorical data.

- **Remove Rows/Columns:** Used when too many values are missing or their impact is minimal.

- **Forward Fill / Backward Fill:** Common in time series data.

- **Prediction-Based Imputation:** Using models to estimate missing values (advanced method).

## Why Handle Missing Values?

### Importance:

- Ensures accuracy of data analysis.

- Prevents errors in formulas, charts, and models.

- Necessary for statistical and machine learning tools that do not accept NaNs or blanks.

### Method Selection:

- **Mean/Median/Mode:** When missing is rare and data is approximately normal.

- **Remove Rows:** When very few rows are missing and deletion won’t hurt insights.

- **Remove Columns:** When a whole column has too many missing values (>40-50%).

- **Median:** Preferred for skewed data.

- **Mode:** For categorical variables.

## Advantages of Handling Missing Values

- Improves data quality and consistency.

- Enables better and more accurate analysis.

- Helps avoid misinterpretations and invalid models.

- Makes the dataset ready for advanced analytics and machine learning.

## How to Handle Missing Values in Excel

### (a) Normal Excel Method (Manual)

### Replace with Mean/Median/Mode:

1. Select empty cells.

2. In a blank cell, use:

    - `=AVERAGE` (range) for mean

    - `=MEDIAN` (range) for median

    - `=MODE.SNGL` (range) for mode

3. Copy the result and paste it into the missing cells.

### Delete Rows/Columns:

1. Select the entire row/column with missing data.

2. Right-click and choose Delete.

3. Choose Shift cells up/left or delete entire row/column.

### (b) Power Query Method

Step-by-step:

1. Go to Data tab → Click Get & Transform Data → From Table/Range.

2. In Power Query Editor:

    - **Replace Values:** **Home** → **Replace Values** → Enter null → Replace with Mean/Median/Mode.

    - **Remove Rows/Columns:** Right-click row/column → **Remove**.

3. Click Close & Load to bring clean data back to Excel.

## Examples

### (a) Replace with Mean/Median/Mode

**Example Dataset:**

|ID |Score |
|:----:|:----:|
|1|80|
|2| |
|3 |75|
|4 | |
|5 |90 |

**Steps:**

`Mean == AVERAGE(B2:B6)` → Fill missing cells with 81.67

`Median == MEDIAN(B2:B6)` → Fill missing cells with 80

`Mode (if categorical) == MODE.SNGL(B2:B6)`

### (b) Delete Rows/Columns

**Example Dataset:**

|Name |Age | Email|
|:----:|:----:|:----:|
|John |25 |john@email.com|
|Ann | |ann@email.com|
|Mike |30 | |

**Action:**

- Delete rows where Age or Email is missing.

## Summary

Handling Missing Values is a core data cleaning operation that helps maintain the integrity of your dataset. In Excel, this can be done manually or via Power Query by:

- Replacing blanks with calculated values (mean/median/mode).

- Deleting rows or columns with missing data.

These techniques ensure your data is clean, reliable, and ready for further analysis or reporting.

### Exercises

**Exercise 1: Replace with Mean**
- **Dataset:** Column of 10 student scores with 2 missing.
- **Task:** Replace missing with mean.

**Exercise 2: Replace with Mode**
- **Dataset:** Column of fruit names with blanks.
- **Task:** Replace missing with the most frequent fruit name.

**Exercise 3: Delete Rows**
- **Dataset:** 10 rows with Name, Age, and Email.
- **Task:** Delete rows where either Age or Email is missing.
