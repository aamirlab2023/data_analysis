cost_price = [800, 1200, 550, 2750, 3300, 1500]
sell_price = []

for price in cost_price:
    sell_price.append(price + 0.3*price)

print(sell_price)
