cost_price = [800, 1200, 550, 2750, 3300, 1500]
sell_price = []

item_price = cost_price[0] + (30/100)*cost_price[0]
sell_price.append(item_price)

item_price = cost_price[1] + (30/100)*cost_price[1]
sell_price.append(item_price)

item_price = cost_price[2] + (30/100)*cost_price[2]
sell_price.append(item_price)

item_price = cost_price[3] + (30/100)*cost_price[3]
sell_price.append(item_price)

item_price = cost_price[4] + (30/100)*cost_price[4]
sell_price.append(item_price)

item_price = cost_price[5] + (30/100)*cost_price[5]
sell_price.append(item_price)

print(sell_price)
