l = ['a', 'b', 'c']
for counter, value in enumerate(l):
    print(counter, value)
