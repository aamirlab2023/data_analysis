# Conditional Formatting

## Introduction

Conditional Formatting allows you to apply visual formatting (colors, icons, etc.) to cells based on their values or formulas.

- **Highlight Cells Based on Rules:** Applies formatting (like background color, font color) to cells that meet specific criteria (e.g., greater than 100, equal to "Pending").

- **Data Bars, Color Scales, Icon Sets:**

    - **Data Bars:** Fill a portion of the cell with a colored bar based on value.

    - **Color Scales:** Color gradients that indicate low-to-high values.

    - **Icon Sets:** Small symbols (arrows, flags, circles) indicating trends or thresholds.

## The Why Section

- To quickly identify patterns or outliers.

- To enhance data visualization without creating charts.

- To improve data readability and interpretation.

## Advantages

|Feature | Benefits |
|:-----|:-----|
|Highlight Rules | Spot errors, duplicates, or thresholds quickly |
|Data Bars | Compare values visually within a column |
|Color Scales | Visual gradient showing data distribution |
|Icon Sets | Add intuitive icons to assess performance (e.g., ↑↓=) |

## Practical

### (a) Normal Excel Way

1. Select the data range.

2. Go to **Home** tab → **Conditional Formatting**.

3. Choose:

    - Highlight Cell Rules (e.g., Greater Than, Text Contains).

    - Top/Bottom Rules (e.g., Top 10%, Bottom 5).

-   Data Bars, Color Scales, or Icon Sets.

4. Customize the rule, color, or thresholds as needed.

### (b) Power Query Way

Power Query does not support conditional formatting directly. To apply conditional visuals, first load data via Power Query. Then, apply conditional formatting in Excel after loading the cleaned data.

## Examples

**Highlight Cells Based on Rules**

1. Highlight scores less than 50 in red.

2. Highlight cells that contain the word “Delayed”.

**Data Bars, Color Scales, Icon Sets**

1. **Data Bars:** Show longer bars for higher sales.

2. **Color Scales:** Use green to red to visualize temperatures.

3. **Icon Sets:** Show ↑ for profits above average, → for average, ↓ for below average.

## Summary

Conditional Formatting visually emphasizes data using color and symbols based on value-driven conditions. It helps highlight key data, spot trends, and simplify interpretation. This includes rules (e.g., highlight values above X) and visuals (bars, scales, icons).

## Exercises

### Exercise 1: Highlight Cells

Highlight students scoring below 40 in red.

### Exercise 2: Data Bars

Apply data bars to sales data to show value comparisons visually.

### Exercise 3: Icon Sets

Use arrow icons to indicate performance:

↑ for >80,

→ for 50–80,

↓ for <50
