f = open("data.txt", "r")
lines = f.readlines()
f.close()

complete_data = []
for counter in range(1, len(lines)):
    line = lines[counter].split(", ")
    data = []
    for i in range(len(line)):
        if i == 0:
            data.append(line[i])
        else:
            data.append(float(line[i]))
    complete_data.append(data)

item = []
cost = []
sell = []
for i in complete_data:
    for j in range(len(i)):
        if j == 0:
            item.append(i[j])
        elif j == 1:
            cost.append(i[j])
        elif j == 2:
            sell.append(i[j])

profit = []
for counter, cost_price in enumerate(cost):
    profit.append(sell[counter] - cost_price)

print(profit)
