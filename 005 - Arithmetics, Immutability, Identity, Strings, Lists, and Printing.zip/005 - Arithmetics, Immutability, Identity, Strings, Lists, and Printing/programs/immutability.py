x = 5
y = x
print(id(x))
print(id(y))
x = 12
print(id(x))
print(id(y))
