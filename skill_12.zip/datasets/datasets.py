import pandas as pd
import random

def generate_autofilter_data():
    products = [f"Product_{i}" for i in range(1, 21)]
    prices = [round(random.uniform(20, 200), 2) for _ in range(20)]
    stock = [random.randint(0, 100) for _ in range(20)]
    df = pd.DataFrame({'Product': products, 'Price': prices, 'Stock': stock})
    df.to_excel("autofilter_data.xlsx", index=False)

def generate_custom_filter_data():
    employees = [f"Employee_{i}" for i in range(1, 31)]
    ages = [random.randint(25, 60) for _ in range(30)]
    salaries = [random.randint(30000, 100000) for _ in range(30)]
    df = pd.DataFrame({'Name': employees, 'Age': ages, 'Salary': salaries})
    df.to_excel("custom_filter_data.xlsx", index=False)

def generate_advanced_filter_data():
    states = ['Texas', 'California', 'Florida', 'New York']
    customers = [f"Customer_{i}" for i in range(1, 31)]
    purchases = [round(random.uniform(100, 2000), 2) for _ in range(30)]
    df = pd.DataFrame({
        'Customer': customers,
        'State': [random.choice(states) for _ in customers],
        'Purchase_Amount': purchases
    })
    df.to_excel("advanced_filter_data.xlsx", index=False)

if __name__ == "__main__":
    generate_autofilter_data()
    generate_custom_filter_data()
    generate_advanced_filter_data()
    print("Filtering datasets created.")
