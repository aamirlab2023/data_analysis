# Filtering Data

## Introduction

- **Filtering Data:** Hides rows that don’t match specified criteria so only relevant data is displayed.

- **AutoFilter:** A quick filtering tool that adds dropdown menus to each column header, letting you filter by value or condition.

- **Advanced Filter:** A more powerful method where you define criteria in a separate range and copy results to another location.

- **Custom Filter Conditions:** Used within AutoFilter to filter data using logical conditions (e.g., “greater than 100”, “contains ‘Manager’”).

## The Why Section

|Purpose |Description |
|:------|:-----|
|Purpose | Description |
|Simplify analysis | Narrow down to relevant data only |
|Focused views | Isolate specific records (e.g., customers from one city) |
|Efficient reports | Show only data that meets complex criteria |
|Reusability | Advanced filters can be reused without manually resetting conditions|

## Advantages

|Feature | Advantages |
|:-----|:-----|
|Filtering | Easy to hide/show data without deleting |
|AutoFilter | Quick, user-friendly, real-time filtering |
|Advanced Filter | Complex and multi-condition filtering |
|Custom Conditions | Greater control with conditions like AND, OR, etc.|

## Practical

### (a) Normal Excel Method

- **AutoFilter:**

    1. Select the data.

    2. Go to **Home > Sort & Filter > Filter**.

    3. Click dropdown arrows in column headers to filter.

- **Custom Filter Conditions:**

    1. Follow steps for AutoFilter.

    2. Choose “**Number Filters**” **/** “**Text Filters**” > select condition (e.g., “**Greater Than**”).

- **Advanced Filter:**

    1.  Create a criteria range (with headers and conditions).

    2. Go to **Data > Advanced** (in Sort & Filter group).

    3. Choose filter in place or copy to another location.

### (b) Using Power Query

- All Filters:

    1.  Go to **Data > From Table/Range**.

    2. In Power Query editor:

        - Click column filter icon.

        - Use dropdown, conditions, or advanced filtering logic.

    3. Click **Close & Load** to output filtered data.

## Examples

|Type | Example |
|:-----|:-----|
|Filtering | Hide all employees not in the “Sales” department. |
| AutoFilter | Filter product list to show only items with stock < 50.|
|Custom Filter | Filter salaries > 60,000 and < 80,000.|
|Advanced Filter | Display customers from “NY” who made purchases > $500.|

## Summary
Filtering Data in Excel helps isolate relevant records. AutoFilter provides dropdown filters, while Custom Filter Conditions allow more precise control. Advanced Filter lets users filter using conditions set in a range and can even output results to another area. Power Query enhances filtering with more flexibility and dynamic loading.

## Exercises

### Exercise 1: AutoFilter

Filter a dataset to display only products with a price less than $100.

### Exercise 2: Custom Filter

Filter employee records where age is between 30 and 50.

### Exercise 3: Advanced Filter

From a customer dataset, show only those who purchased over $1,000 and live in “Texas.”
