# Logical Functions

## Introduction

|Function|	Description|
|:-----|:-----|
|IF(condition, value_if_true, value_if_false)|	Returns one value if the condition is TRUE, and another if FALSE.|
|AND(condition1, condition2, …)|	Returns TRUE only if all conditions are TRUE.|
|OR(condition1, condition2, …)	|Returns TRUE if any condition is TRUE.|
|IFERROR(value, value_if_error)|	Returns the second value if the first results in an error.|
|IFS(condition1, result1, [condition2, result2], ...)|	Evaluates multiple conditions and returns the result of the first TRUE one.|
|SWITCH(expression, value1, result1, [value2, result2], ..., default)|	Matches one expression to multiple values and returns the corresponding result.|

## The Why Section

Logical functions are used to:

- Automate decision-making within Excel sheets.

- Handle conditional logic (e.g., grading, bonuses, classifications).

- Manage errors gracefully.

- Simplify complex nested IFs.

- Perform multi-condition evaluations and value lookups.

## Advantages

- Reduces manual checks and speeds up analysis.

- Enhances data integrity by handling unexpected values or errors.

- Replaces complex nested logic with readable formulas.

- Allows dynamic responses to changes in data.

## Practical

### (a) Normal Way (Excel Worksheet)

1. Type your dataset in Excel.

2. Select a cell and type a formula like `=IF(A2>50,"Pass","Fail")`.

3. Press **Enter** to apply.

Excel’s Formula tab also offers a function insert dialog:

- Go to **Formulas > Logical** to choose `IF`, `AND`, `OR`, etc.

### (b) Power Query Way

1. Go to **Data > Get & Transform > From Table/Range**.

2. In the Power Query Editor:

    - Use **Add Column > Conditional Column** (like `IF`).

    - Use **Custom Column** with M-code for `AND`, `OR`, etc.

    - Example: `if [Score] > 50 and [Grade] = "A" then "Top Student" else "Needs Work"`

Power Query doesn’t support SWITCH, IFS, or IFERROR directly, but similar logic can be created using nested `if...then...else` constructs.

## Examples

|Function	|Example|	Result	|Explanation|
|:-----|:-----|:-----|:-----|
|`IF`	|`=IF(A2>=60,"Pass","Fail")`	|Pass|	Checks if score ≥ 60|
|`AND`|	`=AND(A2>50,B2="Yes")`|	`TRUE`|	Both conditions must be `TRUE`|
|`OR`|	`=OR(A2>90,B2="Yes")`	|`TRUE`|	Only one condition needs to be `TRUE`|
|`IFERROR`	|`=IFERROR(A2/B2, "Error")`|	`Error`|	Avoids divide-by-zero `error`|
|`IFS`	|`=IFS(A2>=90,"A",A2>=80,"B",A2>=70,"C")`	|B|	Returns first true match|
|`SWITCH`|	`=SWITCH(A2,"NY","New York","CA","California","Unknown")`|	New York|	Returns value matching A2|

## Summary

Logical functions in Excel empower users to automate decisions, handle errors, and simplify complex logic using formulas like IF, AND, OR, IFERROR, IFS, and SWITCH. They are key tools in data analysis, validation, and reporting, and work both in traditional Excel formulas and Power Query (to a limited extent).

## Exercises

### Exercise 1: Pass/Fail Logic

- **Dataset:** Student scores

- **Task:** Use `IF` to classify as "Pass" if score ≥ 50, else "Fail".

### Exercise 2: Bonus Eligibility

- **Dataset:** Employee Sales and Attendance

- **Task:** Use `AND` to check if sales > 10000 and attendance = "Excellent".

### Exercise 3: Grading System

- **Dataset:** Exam scores

- **Task:** Use `IFS` to assign grades:

|Score | Grade |
|:-----|:-----:|
|≥ 90 | A|
|≥ 80 | B|
|≥ 70 | C|
|< 70 | F|