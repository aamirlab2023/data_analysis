# Trimming White Spaces in Microsoft Excel

This skill will teach you how to trim white spaces in Microsoft Excel.

## What is Trimming White Spaces?

Trimming white spaces in Microsoft Excel refers to the process of removing unnecessary spaces from text data in cells. These spaces can be leading spaces (before the text), trailing spaces (after the text), or multiple spaces between words. Excel provides tools like the TRIM function to standardize text by keeping only single spaces between words and removing extra spaces at the beginning or end.

## Why Trim White Spaces?

White spaces can cause issues in data processing, analysis, and reporting:

- **Data Consistency:** Extra spaces can make identical entries appear different (e.g., "Apple" vs. "Apple "), leading to errors in sorting, filtering, or lookups.

- **Accuracy in Formulas:** Functions like VLOOKUP or MATCH may fail if spaces cause mismatches.

- **Professional Output:** Clean data ensures reports and outputs look polished and accurate.

- **Database Integration:** When exporting data to other systems, extra spaces can cause integration errors.

## Advantages of Trimming White Spaces

- **Improved Data Quality:** Ensures consistency, making data easier to analyze and compare.

- **Enhanced Formula Reliability:** Prevents errors in functions that rely on exact text matches.

- **Time Efficiency:** Automates cleaning, saving time compared to manual editing.

- **Better Data Visualization:** Clean text improves the appearance of charts, tables, and reports.

- **Compatibility:** Clean data integrates better with external databases or software.

## How to Trim White Spaces

### (a) Normal Way (Using TRIM Function)

1. **Select a Cell:** Choose a cell where you want the trimmed result (e.g., `B1`).

2. **Enter TRIM Formula:** Type `=TRIM(A1)` in the formula bar, where `A1` is the cell with text containing extra spaces.

3. **Press Enter:** The trimmed text appears in `B1`.

4. **Copy Formula:** Drag the fill handle (small square at the bottom-right of the cell) down to apply to other cells.

5. **Convert to Values (Optional):**

    - Select the cells with `TRIM` formulas (e.g., `B1:B10`).

    - Press `Ctrl + C` to copy.

    - Right-click, select **Paste Special** → **Values**, and click **OK** to replace the original data with trimmed text.

6. **Replace Original Data (Optional):** Copy the trimmed values and paste them over the original column (e.g., `A1:A10`).

### (b) Power Query Way

1. **Select Data:** Highlight the range containing text (e.g., `A1:A10`).

2. **Open Power Query:**

    - Go to **Data** tab → **Get & Transform Data** group → **From Table/Range**.

    - In the dialog box, confirm the range and check **My table has headers** if applicable, then click **OK**.

3. **Trim in Power Query:**

    - In the **Power Query Editor**, select the column with text (e.g., Column1).

    - Go to **Transform** tab → **Text Column** group → **Trim**. This removes leading and trailing spaces.

    - (Optional) To remove extra spaces between words, use **Replace Values** to replace multiple spaces with a single space.

4. **Apply Changes:**

    - Click **Home** → **Close & Load** to return the cleaned data to a new table in Excel.

5. **Replace Original Data (Optional):** Copy the cleaned data and paste it over the original column.

## Examples of Trimming White Spaces

**Example 1: Using TRIM Function**

- **Input (`A1`):** " Apple Pie "

- **Formula (`B1`):* `=TRIM(A1)`

- **Output:** Apple Pie

- **Explanation:** Leading and trailing spaces are removed, and multiple spaces between "Apple" and "Pie" are reduced to one.

- **Example 2: Using Power Query**

- **Input Table:**

| Product |
|:----|
|" Orange "|
|"Banana "|
|" Pear "|

- **Steps:**

    - Load the table into Power Query.

    - Select the "Product" column, apply **Trim** from the **Transform** tab.

    - **Close & Load** to Excel.

- **Output Table:**

|Product|
|:----|
|Orange|
|Banana|
|Pear|

## Summary

Trimming white spaces in Excel involves removing unnecessary spaces from text to ensure data consistency and accuracy. The TRIM function is a simple, formula-based method to clean text in a single column, while Power Query offers a scalable solution for larger datasets, allowing batch processing and integration with other transformations. This skill is essential for data cleaning, improving formula accuracy, and preparing data for analysis or export.

## Exercises

**Exercise 1: Basic TRIM Function**

- **Task:** Create a column with messy text (e.g., " John Doe ", " Jane Smith "). Use the TRIM function to clean the data and convert the results to values.
- **Goal:** Ensure all names have no extra spaces.

**Exercise 2: Power Query Cleaning**

- **Task:** Import a table with a column of product names containing extra spaces (e.g., " Widget A ", " Gadget B "). Use Power Query to trim spaces and load the cleaned data back to Excel.
- **Goal:** Verify the output table has no extra spaces.

**Exercise 3: Combining TRIM with Other Functions**

- **Task:** Clean a list of email addresses with extra spaces (e.g., " user @domain.com ") and convert them to lowercase using TRIM and LOWER functions.
- **Goal:** Ensure emails are lowercase and free of extra spaces.
