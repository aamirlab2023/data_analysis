# Using Formulas to Reshape Data

## Introduction

Reshaping data using formulas in Excel means transforming text and numbers into new formats or structures using specific functions. It involves combining, extracting, changing case, and converting data types.

**Subskills:**

- **CONCATENATE / TEXTJOIN:** Combine text from multiple cells.

- **LEFT, RIGHT, MID:** Extract specific portions of a string.

- **UPPER, LOWER, PROPER:** Change the case of text.

- **VALUE, TEXT:** Convert between numbers and text formats.

## The Why Section

- **Standardization:** Ensures data is in a consistent format.

- **Data Cleaning:** Extracts necessary parts and removes irrelevant content.

- **Preparation:** Makes data ready for analysis or reporting.

- **Automation:** Saves time by avoiding manual editing.

## Advantages

- Quick data manipulation without manual re-entry.

- Reduces human errors.

- Works dynamically – changes update automatically when source data changes.

- Can handle large datasets efficiently.

## Practical

### (a) Normal Excel Way

1. Click on a blank cell where the result should appear.

2. Type the formula (e.g., `=CONCATENATE(A2, B2)` or `=LEFT(A2, 5)`).

3. Press Enter.

4. Drag the fill handle to apply the formula to more rows if needed.

### (b) Power Query Way

1. Select your data > Go to **Data > Click From Table/Range**.

2. In the Power Query Editor:

    - Use **Add Column > Custom Column** for formulas.

    - Use **Transform** tab to extract text (e.g., LEFT, RIGHT).

    - Use **Format** options for UPPER, LOWER, etc.

3. Click **Close & Load** to apply and return reshaped data to Excel.

## Examples

|Function | Example Formula | Result (Assuming `A2="John", B2="Doe"`) |
|:-----|:-----|:-----|
|`CONCATENATE` | `=CONCATENATE(A2, " ", B2)` | John Doe |
|`TEXTJOIN` | `=TEXTJOIN(" ", TRUE, A2, B2)` | John Doe |
|`LEFT` | `=LEFT(A2, 2)` | Jo |
|`RIGHT` | `=RIGHT(B2, 2)` | oe |
|`MID` | `=MID(A2, 2, 2)` | oh |
|`UPPER` | `=UPPER(A2)` | JOHN |
|`LOWER` | `=LOWER(B2)` | doe |
|`PROPER` | `=PROPER("john doe")` | John Doe |
|`VALUE` | `=VALUE("123")` | 123 (number format) |
|`TEXT` | `=TEXT(123.456, "0.00")` | 123.46 (formatted as text) |

## Summary
Using formulas to reshape data is the process of manipulating and transforming cell values using functions such as CONCATENATE, TEXTJOIN, LEFT, RIGHT, MID, UPPER, LOWER, PROPER, VALUE, and TEXT. These functions help standardize, clean, and format data efficiently for analysis, reporting, or presentation.

## Exercises

### Exercise 1: Combine First and Last Names

- **Columns:** First Name, Last Name

- **Task:** Use TEXTJOIN to create Full Name.

### Exercise 2: Extract Area Code

- **Column:** Phone Number (e.g., "(123) 456-7890")

- **Task:** Use MID to extract the area code (123).

### Exercise 3: Format Salary

- **Column:** Salary (Text) with values like "50000"

- **Task:** Convert to numeric using VALUE, then format as currency using TEXT.
