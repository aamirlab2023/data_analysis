# Error Checking

## Introduction

Error Checking in Excel refers to the process of:

- Detecting incorrect formulas, references, or data.

- Diagnosing the cause of the error.

- Correcting the formula or value.

- Excel highlights errors using standard error codes such as:

    - `#DIV/0!` – Division by zero

    - `#VALUE!` – Wrong type of argument

    - `#REF!` – Invalid cell reference

    - `#NAME?` – Unrecognized text in a formula

    - `#N/A` – Value not available

    - `#NUM!` – Invalid numeric value

## The Why Section

- To ensure accuracy and reliability of calculations.

- To prevent downstream errors in linked data.

- To maintain data integrity in reports and dashboards.

## Advantages

|Advantage | Description |
|:-----|:-----|
|Improved Accuracy | Detect mistakes in formulas early |
|Error Resolution | Fix broken links or bad inputs |
|Confidence in Output | Trust that results are correct |
|Cleaner Reports | Prevents errors from showing to stakeholders |

## Practical

### (a) Normal Excel Way

1. Go to the **Formulas** tab.

2. Click **Error Checking** in the **Formula Auditing** group.

3. Use the arrows to navigate errors.

4. Use **Trace Error, Evaluate Formula**, or **Show Formulas** to inspect issues.

**Other tools:**

- Trace Precedents/Dependents

- Evaluate Formula (step-by-step formula debugging)

- Green triangle alerts (show cells with potential issues)

### (b) Power Query Way

1. Load data via **Data > From Table/Range**.

2. In Power Query Editor:

    - Use **Transform > Detect Data Type** to check invalid types.

    - Use conditional columns or filters to find **null**, **error**, or **mismatched** values.

    - Errors are displayed directly in Power Query (e.g., “Error” row).

    - Right-click error cell > **Remove Errors** or **Replace Errors**.

## Examples

### Formula Error Examples

1. `=A1/B1` where B1 is 0 > `#DIV/0!`

2. `=VLOOKUP("X", A1:B10, 3, FALSE)` where 3 is an invalid column > `#REF!`

### Data Error Examples (Power Query or manual check)

1. Missing birthdate > Null or Error in calculated age column.

2. Text in a numeric column > `#VALUE!` in sum calculations.

## Summary

Error Checking in Excel ensures that formulas and data are valid and functional. By identifying issues like division by zero, wrong references, or missing values, users can maintain reliable and clean spreadsheets. Excel provides built-in tools, and Power Query allows identifying and handling data errors dynamically.

## Exercises

### Exercise 1

Intentionally create a `#DIV/0!` error and use Error Checking to identify and fix it.

### Exercise 2

Use Evaluate Formula to troubleshoot a nested formula that returns `#VALUE!`.

### Exercise 3

In Power Query, load a table with invalid dates and use Replace Errors to correct them.
