> # Python for Data Analysis
> # The Conditional (`while`) Loop
> # Dr. Aamir Alaud Din
> # June 22, 2025

> # Table of Contents

1. Recap
2. Objectives
3. The Why Section
4. Algorithm and Pseudocode
5. Program
6. Summary
7. Exercises

> # Recap

- Use Nikol Tesla's strategy to develop algorithms.

- Developing algorithm and pseudocode reduces the chances of bugs in the programs.

- Write python programs and follow some standard of writing as it will help you if you encounter your own program after a long time.

- Majority of the programs have bugs after first draft of code.

- Develop curiosity in debugging so that you play with bugs, enjoy debugging, and remin comfortable with them.

- Printing of every line/output is a powerful debugging method which also has a high probability of catching even the non syntax bugs.

- Comments are very useful in python programs as they remind us different things when the code is reopened after a long time for modification or upgradation.

- Comments start with the `#` symbol and are ignored by python interpreter as they are for programmer's reference only.

- Comments spanning several lines are enclosed within tripple quotes and they appear as they are typed in the text editor.

- Every python program, which has to be released for the users, must contain the program documentation.

- Documentation is incorporated at the start of a program and just after the function definition lines.

- If it is required to float a program to the community, it is necessary to incorporate the license so that users use the program as per the license sections.

> # Objectives

- Describe in your own words, the conditional repetitions (loops).

- Explain conditional loops with the aid of a flowchart.

- Implement `while` loops in conditional repetitive computaions.

> # The Why Section

- In daily life, we encounter many repetitive actions.

- Some repetitions are counted while other are linked to the fulfillment of a condition.

- If I ask you, how many times you offer prayer in a day?

- Definitely, your answer is going to be five times a day.

- This is the example of a counted repetitive activity.

- If I ask you how many bites you take in breakfast?

- Your answer will be, it depends on my apetite.

- The number of bites is linked to the condition of apetite.

- In the same way, there may be counted and conditional repetitive computations in computer programming.

- If you consider the program of projectile's maximum height and range (topic 9), we first found the time to reach maximum height and then maximum height.

- How to solve the same problem with repetitive calculations?

- We pose another more simpler problem.

- How to generate the first `n` integers and sum them using a conditional repetitive calculation?

- The repetitive calculations are linked to the fulfillment of a condition.

- How to update the fulfillment condition to stop the computation?

- What is the general structure of such conditional repetitive programs?

- How to develop a flowchart for these conditional calculations to help develop the code?

- We answer to all these questions shortly.

> # Algorithm and Pseudocode

- We understand the background and concepts of conditional loop with the following example.

- Convert the celcius temperature to fahrenheit temperature with celcius temperature ranging from $0$ through $25$ with an increment of $5$ degrees of celcius (i.e., for celcius temperatures of $0$, $5$, $10$, $15$, $20$, and $25$ degrees of celcius).

- Print the values of celcius and fahrenheit calculations for every input of celcius temperature.

- For conversion of one input celcius temperature to the corresponding fahrenheit temperature and its printing, following three repetitions are required.

	1. Convert the celcius temperature to fahrenheit temperature.

	2. Print the celcius and corresponding fahrenheit temperatures.

	3. Increment the celcius temperature by \(5\) degrees.

- For six input temperatures (\(0, 5, 10, 15, 20, 25\)), there will be eighteen repetitions.

- This naive solution to the problem is to use the conversion formula \(\frac{9}{5}C + 32\) for every input value of celcius temperature and print the corresponding celcius and fahrenheite temperatures.

- To see this naive solution [click here](../programs/naive.py).

- In real world problems, the inputs may be in millions, for example, 500,000 input values of celcius temperatures.

- The repetetive steps in such a case will be 1,500,000 steps.

- Writing too many lines of code is not easy and the chance of typing mistake is also possible.

- However, another solution to such problems is also possible using a repetetive structure.

- For this new solution, we review some properties of the above eighteen steps (3 steps repetitions 6 times).

	- The computation starts with $0$ degrees of celcius.

	- The celcius temperatures is incremented by \(5\) degrees of celcius for every next computation.

	- The computation stops at \(25\) degrees of celcius.

- This repetetive program has two properties which are:

	1. Repetition Condition

	2. Repetetive Statements

	## 1. Repetition Condition

	This is the condition based on which decision is taken whether to computer or not. For example in our example, the condition of repetition is `celcius <= 25`. It decides whether to compute or not.

	## 2. Repetetive Statements

	These are the statements which we want to perform repeatedly e.g., in our case, we want to:

	- Convert celcius temperature to fahrenheit temperature.

	- Print the celcius and corresponding fahrenheit temperatures.

	- Update the celcius temperature with an increment of \(5\) degrees celcius.

- Number of repetitions can be calculated using the following formula.

\[
\text{Number of Repetitions} = \frac{\text{Stop Value} - \text{Start Value}}{\text{Increment/Decrement}}
\]

- The flowchart for a general repetetive program is shown below.

![while](../images/1001.png)

***Figure 1.*** A general algorithmic flowchart for conditional repetetive structure.

- **NOTE:** Students are advised to to draw the algorithmic flowchart for conditional repetetive program for the example quoted above.


- The pseudocode for the problem is given below.

```
INPUT celcius = 0
INPUT increment = 5
INPUT stop = 25
DO WHILE celcius <= stop
	CALCULATE fahrenheit = (9/5)*celcius + 32
	DISPLAY celcius, fahrenheit
	CALCULATE celcius = celcius + increment
END WHILE
DISPLAY 'Program terminated successfully.'
```

> # Program

The program for the conversion of celcius temperature into corresponding fahrenheit temperature, using the pseudocode above, is shown below.

```python
celcius = 0
increment = 5
stop = 25
while celcius <= stop:
	fahrenheit = (9/5)*celcius + 32
	print(f"{celcius:9.2f}{fahrenheit:.2f}")
	celcius += increment
```

- Now, we discuss the program execution.

- The first three lines of program are executed only once in which values are assigned to variables (see code below).

```python
celcius = 0
increment = 5
stop = 25
```

- After these three lines, the repetitive structure (`while` loop) starts.

## Run 1

- The test condition is checked i.e., `celcius <= stop` and since `celcius = 0` and `stop = 25`, the condition `celcius <= stop` evaluates to `TRUE` and the next three indented lines are executed.

- The first and second lines in the body of `while` loop calcuate fahrenheit temperature and display the celcius and fahrenheit temperatures.

- In the third line, celcius is incremented by \(5\) degrees and we have `celcius = 5`.


## Run 2

- The test condition is checked i.e., `celcius <= stop` and since `celcius = 5` and `stop = 25`, the condition `celcius <= stop` evaluates to `TRUE` and the next three indented lines are executed.

- The first and second lines in the body of `while` loop calcuate fahrenheit temperature and display the celcius and fahrenheit temperatures.

- In the third line, celcius is incremented by \(5\) degrees and we have `celcius = 10`.

## Run 3

- The test condition is checked i.e., `celcius <= stop` and since `celcius = 10` and `stop = 25`, the condition `celcius <= stop` evaluates to `TRUE` and the next three indented lines are executed.

- The first and second lines in the body of `while` loop calcuate fahrenheit temperature and display the celcius and fahrenheit temperatures.

- In the third line, celcius is incremented by \(5\) degrees and we have `celcius = 15`.

## Run 4

- The test condition is checked i.e., `celcius <= stop` and since `celcius = 15` and `stop = 25`, the condition `celcius <= stop` evaluates to `TRUE` and the next three indented lines are executed.

- The first and second lines in the body of `while` loop calcuate fahrenheit temperature and display the celcius and fahrenheit temperatures.

- In the third line, celcius is incremented by \(5\) degrees and we have `celcius = 20`.

## Run 5

- The test condition is checked i.e., `celcius <= stop` and since `celcius = 20` and `stop = 25`, the condition `celcius <= stop` evaluates to `TRUE` and the next three indented lines are executed.

- The first and second lines in the body of `while` loop calcuate fahrenheit temperature and display the celcius and fahrenheit temperatures.

- In the third line, celcius is incremented by \(5\) degrees and we have `celcius = 25`.

## Run 6

- The test condition is checked i.e., `celcius <= stop` and since `celcius = 25` and `stop = 25`, the condition `celcius <= stop` evaluates to `TRUE` and the next three indented lines are executed.

- The first and second lines in the body of `while` loop calcuate fahrenheit temperature and display the celcius and fahrenheit temperatures.

- In the third line, celcius is incremented by \(5\) degrees and we have `celcius = 30`.

## Termination of Repetition

- This time, `celcius = 30` and `stop = 25` and the condition `celcius <= stop` evaluates to `FALSE` and the three lines of code are not executed anymore.

> # Summary

- A program in which a block of code is to be executed several times and the number of times of repetition is unknown and linked to the fulfillment of a condition is known as the conditional loop or a `while`loop.

- There might be a part of the program before entering the loop.

- The conditional loop starts with the keyword `while`.

- The conditional statement is a logical statement which might be a single or compound logical statement.

- The loop condition terminates at the colon `:`.

- The lines of code which have to be repeated must be indented by a tab stop.

- The indented lines are called the body of `while` loop.

- The indented lines of code keep on executing unless the logical statement evaluates to `FALSE`.

- The test condition variable must be updated within the body of the loop, else the loop will keep on repeating infinitely.

- There may be a part of program after the body of the loop and it must be at the indentation level before the start of body of the loop.

