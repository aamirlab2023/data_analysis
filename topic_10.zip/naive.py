celcius = 0
fahrenheit = (9/5)*celcius + 32
print(f'{celcius:<6d}{fahrenheit:.2f}')

celcius = 5
fahrenheit = (9/5)*celcius + 32
print(f'{celcius:<6d}{fahrenheit:.2f}')

celcius = 10
fahrenheit = (9/5)*celcius + 32
print(f'{celcius:<6d}{fahrenheit:.2f}')

celcius = 15
fahrenheit = (9/5)*celcius + 32
print(f'{celcius:<6d}{fahrenheit:.2f}')

celcius = 20
fahrenheit = (9/5)*celcius + 32
print(f'{celcius:<6d}{fahrenheit:.2f}')

celcius = 25
fahrenheit = (9/5)*celcius + 32
print(f'{celcius:<6d}{fahrenheit:.2f}')
