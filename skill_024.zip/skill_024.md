> # Data Analysis with Microsoft Excel
> # Lookup Functions
> # Dr. Aamir Alaud Din
> # June 30, 2025

> ## Introduction


Lookup functions retrieve data from a table based on a search value:

|Function|	Description|
|:-----|:-----|
|`VLOOKUP`|	Searches vertically in the first column and returns a value from a specified column in the same row.|
|`HLOOKUP`|	Searches horizontally in the first row and returns a value from a specified row in the same column.|
|`XLOOKUP`|	A flexible replacement for both `VLOOKUP` and `HLOOKUP`. Looks vertically or horizontally.|
|`INDEX + MATCH`|	A powerful combo: `INDEX` returns a value from a position, `MATCH` finds that position. Together, they enable dynamic lookups.|

> ## The Why Section

These functions are used to:

- Retrieve related information (e.g., get employee name by ID).

- Connect data from different sheets or tables.

- Enable automation and reduce manual data searching.

- Support dynamic dashboards and reports.

> ## Advantages

- **Time-saving:** Instantly fetch values based on keys.

- **Flexible:** Work across large datasets and sheets.

- **Powerful:** INDEX + MATCH and XLOOKUP can search left, right, up, or down.

- **Dynamic:** Work well with dropdowns, filters, and advanced automation.

> ## Practical

### (a) Normal Way (Using Excel UI)

1. Type your dataset in a sheet.

2. Select a cell and enter a formula like:

`=VLOOKUP(lookup_value, table_array, col_index_num, [range_lookup])`

3. Use **Insert Function (fx)** button for help.

4. Use **Formulas > Lookup & Reference** to choose the desired function.

### (b) Power Query Way

1. Go to **Data > Get & Transform > From Table/Range**.

2. Load two related tables.

3. Use **Home > Merge Queries**:

    - Choose matching column(s)

    - Choose Join kind (Left Join is common)

4. Expand the related table's columns after merging.

> ## Examples

|Function|	Example Formula|	Result|	Explanation|
|:-----|:-----|:-----|:-----|
|`VLOOKUP`|	`=VLOOKUP("E001", A2:C6, 2, FALSE)`|	Alice	|Looks up "E001" in first column and returns name from 2nd column|
|`HLOOKUP`|	`=HLOOKUP("Sales", A1:E3, 2, FALSE)`|	12000|	Finds "Sales" in row 1 and returns value from 2nd row|
|`XLOOKUP`	|`=XLOOKUP("E001", A2:A6, B2:B6)`	|Alice|	Searches for "E001" in `A2:A6` and returns corresponding value from `B2:B6`|
|`INDEX+MATCH`	|`=INDEX(B2:B6, MATCH("E001", A2:A6, 0))`|	Alice|	`MATCH` finds row, `INDEX` returns corresponding value from `B2:B6`|

> ## Summary

Lookup functions allow Excel to retrieve data based on a reference.

- **`VLOOKUP`:** Simple, but only searches right.

- **`HLOOKUP`:** For horizontal data.

- **`XLOOKUP`:** Modern, flexible, handles errors.

- **`INDEX + MATCH`:** Most powerful and dynamic combo, supports advanced lookups.

> ## Exercises

### Exercise 1: Employee Lookup (VLOOKUP)

- **Data:** Employee ID, Name, Department

- **Task:** Use VLOOKUP to return the department based on a given ID.

### Exercise 2: Monthly Revenue (HLOOKUP)

- **Data:** Row 1 has months, Row 2 has revenue

- **Task:** Use HLOOKUP to return revenue for a given month.

### Exercise 3: Product Price Search (INDEX + MATCH or XLOOKUP)

- **Data:** Product ID, Name, Price

- **Task:** Use INDEX + MATCH or XLOOKUP to find the price by product name.
