# Sorting Data

## Introduction

- Single-Level Sorting: Sorting data based on one column only (e.g., sorting by "Name" alphabetically).

- Multi-Level Sorting: Sorting data based on multiple columns in a hierarchy (e.g., sort by "Department" first, then by "Name" within each department).

## The Why Section

- Single-Level Sorting:

    - For quickly locating or organizing data.

    - Useful when only one key matters (e.g., sorting salaries).

- Multi-Level Sorting:

    - To preserve relationships between multiple columns.

    - Essential in structured reports (e.g., department-wise employee lists).

## Advantages of Sorting Data

|Sorting Type |Advantages |
|:-----|:-----|
|Single-Level |	Easy and fast, great for quick analysis|
|Multi-Level | Provides better data hierarchy and context |
|Both | Helps in data visualization, summarizing, and comparison |

## Practical

### (a) Normal Excel Way

- Single-Level Sort:

    1. Click any cell in the column.

    2. Go to **Home > Sort & Filter**.

    3. Choose **Sort A to Z** or **Sort Z to A**.

- Multi-Level Sort:

    1. Select the full data range.

    2. Go to **Data** tab > click **Sort**.

    3. Use “**Add Level**” to specify multiple sorting criteria.

### (b) Using Power Query

- Steps:

    1. Select your data > go to **Data tab > From Table/Range**.

    2. In Power Query editor:

        - Right-click the column > **Sort Ascending or Descending**.

        - For multi-level: sort one column, then sort another.

    3. Click **Close & Load** to load sorted data back to Excel.

## Examples

- **Single-Level Sorting**

    - Sorting employee list by Last Name.

    - Sorting sales by Amount (Descending).

- **Multi-Level Sorting**

    - Sorting by Department (A-Z) then by Salary (High to Low).

    - Sorting students by Class then by Name.

## Summary
Sorting is a vital Excel skill used to organize data either by one criterion (single-level) or by a hierarchy (multi-level). It improves clarity, comparison, and data presentation. Excel allows sorting through standard tools or Power Query for more advanced operations.

## Exercises

### Exercise 1: Single-Level
Sort a list of products by Price (Lowest to Highest).

### Exercise 2: Multi-Level
Sort employee data by Department (A-Z) and then by Name (A-Z).

### Exercise 3: Power Query
Load student grades into Power Query and sort by Subject, then Score (Descending).
