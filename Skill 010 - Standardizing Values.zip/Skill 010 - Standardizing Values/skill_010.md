# Standardizing Values

## Introduction
Standardizing values refers to the process of making data consistent across entries. For example, turning various versions of "yes" (e.g., "Y", "Yes", "yes") into a single, consistent value ("Yes").

## The Why Section

Values are standardized to:

- **Data Consistency:** Ensure consistency in data analysis.

- **Error Reduction:** Avoid errors in filtering, sorting, or summarizing.

- **Reporting and Visualization:** Enable accurate reporting and data visualization.

- **Automation and Merging:** Facilitate automation and data merging from multiple sources.

## Advantages of Standardizing Values

- **Error Reduction:** Reduces data entry errors.

- **Readability:** Improves readability and usability of data.

- **Filtering and Analysis:** Makes filtering and analysis more accurate.

- **Pivot Tables and Dashboards:** Enhances the quality of pivot tables and dashboards.

## How to Standardize Values in Excel

### (a) Normal Way (Manually or Using Formulas):

Use Find and Replace (Ctrl + H):

- Replace all "Y", "yes", etc., with "Yes".

- Replace all "N", "no", etc., with "No".

- Use IF / IFERROR / SWITCH / SUBSTITUTE:

```
=IF(OR(A2="Y", A2="yes", A2="y"), "Yes", IF(OR(A2="N", A2="no", A2="n"), "No", A2))
```
- Use Data Validation to restrict future inputs.

### (b) Using Power Query:

1. Select the data > go to **Data > Get & Transform > From Table/Range**.

2. In Power Query Editor:

    - Use Replace Values for each column (e.g., replace "y", "Y", "yes" → "Yes").

    - Use **Transform > Format** to change case (e.g., lowercase, capitalize).

3. Click **Close & Load** to return standardized data to Excel.

## Examples

**Converting:** 

- "yes", "Yes", "Y", "y" → "Yes"

- "M", "Male", "male" → "Male"

**Changing:**

- "U.S.A.", "us", "United States" → "USA"

## Summary
Standardizing values in Excel is a crucial data-cleaning step to ensure uniformity across entries. It allows for cleaner reports, prevents analysis errors, and supports automation. Methods include manual replace, formulas, and Power Query.

## Exercises

### Exercise 1
Open the dataset and standardize all values in the Consent column to either "Yes" or "No".

### Exercise 2
Use formulas to convert all entries in the Gender column to "Male" or "Female".

### Exercise 3
Use Power Query to standardize all entries in the Country column to either "USA" or "UK".
