# Python Installation and Working Environments

## Objectives

- Describe the philosophy of proprietary and free and open source software (FOSS), in your own words.

- Describe the reason of various installers of python and which installer to use, in your own words.

- Describe, in your own words, the reason of different working environments and select any one for your future use.

## The Why Section

- For famous scientific software like MATLAB, Mathematica, and AutoCAD, there is only one installer provided by the company.

- Each of these software have built in packages e.g., MATLAB has many packages like linear algebra package, statistics package, and differential equations solver package.

- The installer provided by the company not only installs the main software but also installs all the packages.

- Although, python also provides the official installer which install python but not the packages.

- There are many installers of python.

- Then, which installer to use and how to install the packages?

- Just like the installer, the working environment of MATLAB is designed in such a way that the code editor (the file where we write the code), the file explorer (where folders and files are listed), the output window (where we see the results of computations), and many such facilities are available in a [single window](https://www.mathworks.com/help/matlab/matlab_env/change-the-desktop-layout.html)

- But, in case of python, different working environments are available to work in python.

- Then, why are there many different working environments to work in python and which one to use?

- We answer these questions shortly.

## Philosophy of Free and Open Source Software (FOSS)

- First we look into the proprietary software.

- A company hires software engineers, relevant scientists, and engineers and develop the software and makes sure to include all the packages and all the working environments in the software.

- The packages, their algorithms, codes and all other relevant information is decided by the personnel in the company.

- The graphic designers work on graphical user interface of the software.

- The final product is released into the market for sale.

- The marketing team works on marketing of the product.

![FOSS](./images/0201.png)

***Figure 1.*** Philosophy of a proprietary software.

- There is a main core team which develops the main software and releases it and its versions.

- Different universities and organizations download the source code of the main software and modify according to their needs and requirements and release it and its versions with a different name.

- Sometimes, universities and organizations, instead of downloading the code from the main release, download the source code of some other university or organization, modifies according to its needs and requirements and release it and its versions with a different name.

- Different universities and organizations develop the packages which are usually not available in the main/modified software.

- The packages and its versions are released independently with a different name.

- The packages can be imported in the main/modified releases and used.

- Sometimes, the same computaion can be performed using different packages.

- It is because the code for the computation is released in different packages.

- For example, trigonometric functions may be released in different modified releases as well as packages and we can use any of them.

- A graphical representation on the philosophy of free and open source software (FOSS) is shown in the following figure and the best example of free software is [Linux operating system](https://en.wikipedia.org/wiki/Linux_distribution).

![Free](./images/0202.png)

***Figure 2.*** Philosophy of FOSS.

## Python, Python Packages, and Installers

- Python programming languages and its versions are released by Python Software Foundation.

- The installer is released on official webpage of [Python Software Foundation](https://www.python.org/downloads/release/python-3124/).

- There are tens of packages, for various purposes and computations, which can be used with python.

- These packages are not developed by Python Software Foundation and are therefore not released by the company.

- The packages are developed by tens of universities and organizations and knowing about all packages is not easy.

- Python Software Foundation has developed a reposity with the name of Python Package Index abbreviated as [PyPI](https://pypi.org/).

- The packages developed by different universities and organization can be submitted to PyPI from where users can download a package of their interest, install it, import it, and use it.

- If a developed package is not submitted to PyPI and you are aware of it and its developer, you can request the developer of that package to get and use it.

- You can also develop your own packages and submit it to PyPI to help others.

- Continuum Analytics also famous as Operating System of AI releases python along with several famous packages incorporated in python under the name of [Anaconda](https://www.anaconda.com/).

- The company releases python with nearly all packages required in scientific computing and can be [downloaded](https://www.anaconda.com/download).

- It is highly recommended to download the installer for your operating system and install it.

- Once installed, you will hardly need any other package for your computational tasks.

- Downloading python from official website and then installing packages is challenging task if you are new in the world of programming.

## Python Working Environments

- Just like the installers and packages, working environments of Python are also multiple.

- There are two modes of working in python namely, 1) interactive mode and 2) non-interactive mode.

- In the interactive mode, python shows output once you complete any line of code if executed.

- In the non-interactive mode, a python program is written and then python is called to translate it to machine code for computer and vice versa.

- The working environments can also be classified into two categories which are 1) text and console arrangement and 2) Integrated Development Environment IDE.

- Text and console arrangement and IDEs fall under the category of non-interactive mode.

- Examples of interactive mode environments are jupyter notebook and google colab.

- IDLE editor with IDLE console and Kate text editor with Konsole are the examples of text and console arrangements.

- The code is written in the text editor and executed in the terminal (console/konsole).

- Pycharm and Spyder belong to IDE class of python where text editor, console, file explorer, and some other features are integrated in the same window.

![Jupyter](./images/0203.png)

***Figure 3.*** A snapshot of jupyter notebook.

![Colab](./images/0204.png)

***Figure 4.*** A snapshot of google colab.

![IDLE_Editor](./images/0205.png)

***Figure 5.*** A snapshot of IDLE code editor.

![IDLE_Output](./images/0206.png)

***Figure 6.*** A snapshot of IDLE output.

![IDLE_Console](./images/0207.png)

***Figure 7.*** A snapshot of IDLE console.

![Kate](./images/0208.png)

***Figure 8.*** A snapshot of Kate text editor.

![Konsole](./images/0209.png)

***Figure 9.*** A snapshot of Kubuntu Konsole (Linux Terminal).

![PyCharm](./images/0210.png)

***Figure 10.*** A snapshot of Pycharm IDE.

![PyCharm_Output](./images/0211.png)

***Figure 11.*** A snapshot of Pycharm IDE output.

![Spyder](./images/0212.png)

***Figure 12.*** A snapshot of Spyder IDE (file and variable explorer can be seen).

![SpyderPlot](./images/0213.png)

***Figure 13.*** A snapshot of Spyder IDE (plot explorer can be seen).

![VIM](./images/0214.png)

***Figure 14.*** A snapshot of vim text editor (converted to IDE).

![VIMExecute](./images/0215.png)

***Figure 15.*** A snapshot of vim IDE file execution method.

![VIMOut](./images/0216.png)

***Figure 16.*** A snapshot of vim IDE output.

## Summary

- Python is a free programming language licensed under PSF which can be downloaded, distributed, installed, and used free (libre).

- Python packages are released by PyPI.

- Anaconda provides python with several packages incorporated which is very useful specially for the newbies.

- Python has different working environments including interactive mode, text and terminal, and IDE arrangements.

- The installer provided by Anaconda and Spyder IDE (because it has MATLAB like layout as well) are highly recommended for scientific computing.

- For newbies, vscode (not shown above) is the recommended IDE.
