#!/usr/bin/env python3
"""
    sine_wave_vim.py - This program generates an array of angles from 0 to 2 pi
    and another array of the sine function of angle array. The program plots
    the arrays and displays in plot window.

    Copyright (C) 2024 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""


import numpy as np
import matplotlib.pyplot as plt


x = np.linspace(0, 6.29, 200)
y = np.sin(x)

plt.plot(x, y, '-k')
plt.show()
