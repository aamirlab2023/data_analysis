#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 6.29, 200)
y = np.sin(x)

plt.plot(x, y, '-k')
plt.show()
