# Removing Duplicates

## What is Data Removal of Duplicates?

Removing duplicates means identifying and deleting repeated rows or values in a dataset. This ensures each data entry appears only once, preserving the accuracy and integrity of your analysis.

## Why Are Duplicates Removed?

**Maintain Data Accuracy:** Avoid incorrect calculations due to repeated values.

**Cleaner Data:** Essential in reports, summaries, and visualizations.

**Better Performance:** Reduces file size and processing time.

**Integrity in Analysis:** Ensures meaningful insights and decisions.

## Advantages of Removing Duplicates

- Prevents double-counting.

- Improves data readability.

- Helps in unique data identification.

- Essential for merging and consolidating data.

- Improves performance in large datasets.

## How to Remove Duplicates in Microsoft Excel

### (a) Normal Way (Ribbon Method)

- Select the data range.

- Go to **Data** tab.

- Click **Remove Duplicates** in the **Data Tools** group.

- A dialog box appears – check/uncheck columns to base duplicate removal on.

- Click **OK**.

- Excel will show how many duplicate values were removed.

### (b) Power Query Way

- Select your data and go to **Data** → **Get & Transform Data** → **From Table/Range**.

In Power Query Editor:

- Select the columns to consider.

- Click **Remove Duplicates** (on the Home tab).

- Click **Close & Load** to bring the cleaned data back to Excel.

## Examples

### (a) Normal Way

**Example 1:** Removing duplicate rows in a list of customer names.

**Example 2:** Removing duplicate email addresses from a newsletter list.

### (b) Power Query Way

**Example 1:** Removing duplicates based on a single column in sales data.

**Example 2:** Removing duplicates based on multiple columns in a product catalog.

## Summary

Removing Duplicates is essential to keep your data clean and analysis accurate. Excel offers two effective methods: the simple Remove Duplicates tool in the Data tab, and a more dynamic method using Power Query. Mastery of both methods ensures you can handle diverse and complex data cleaning tasks confidently.

### Exercises

**Exercise 1 (Normal Way):**
You have a student list with repeated names. Remove duplicate entries based on the name column only.

**Exercise 2 (Power Query):**
Load a dataset of employee records and remove duplicates based on the combination of "Employee ID" and "Department".

**Exercise 3 (Both Methods):**
You have a dataset of online orders. Remove rows where both "Customer ID" and "Product ID" are repeated.
