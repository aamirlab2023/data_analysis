For the Microsoft Excel skill titled "Removing Duplicates"
Explain in detail
1. What is data removal of duplicated?
2. Why duplicates are removed?
3. What are the advantages of removing duplicates?
4. How to remove duplicates (which buttons to click to complete the task) using Microsoft Excel in (a) normal way and (b) Power Querry way?
5. Give two examples of removing duplicates in (a) normal way and (b) Power Query way?
6. Give me summary of the skill.
7. Give me three exercises to practice.
8. Also give me the python file to generate the data sets required for the examples and exercises.
