import pandas as pd
import random
import numpy as np

# Set seed for reproducibility
random.seed(1)
np.random.seed(1)

# Example 1 - Normal Way
df1 = pd.DataFrame({
    "Customer Name": ["Alice", "Bob", "Alice", "David", "Bob", "Eve"]
})
df1.to_excel("example1_normal.xlsx", index=False)

# Example 2 - Normal Way
df2 = pd.DataFrame({
    "Email": ["alice@mail.com", "bob@mail.com", "alice@mail.com", "eve@mail.com", "eve@mail.com"]
})
df2.to_excel("example2_normal.xlsx", index=False)

# Example 1 - Power Query
df3 = pd.DataFrame({
    "Order ID": [101, 102, 103, 101, 104],
    "Product": ["Laptop", "Phone", "Tablet", "Laptop", "Monitor"]
})
df3.to_excel("example1_powerquery.xlsx", index=False)

# Example 2 - Power Query
df4 = pd.DataFrame({
    "Product ID": [1, 2, 1, 3, 2],
    "Category": ["Electronics", "Clothing", "Electronics", "Home", "Clothing"]
})
df4.to_excel("example2_powerquery.xlsx", index=False)

# Exercises Dataset
df5 = pd.DataFrame({
    "Student Name": ["Ali", "Sara", "Ali", "Usman", "Sara"],
    "Grade": ["A", "B", "A", "C", "B"]
})
df5.to_excel("exercise1.xlsx", index=False)

df6 = pd.DataFrame({
    "Employee ID": [1001, 1002, 1001, 1003, 1002],
    "Department": ["HR", "Finance", "HR", "IT", "Finance"]
})
df6.to_excel("exercise2.xlsx", index=False)

df7 = pd.DataFrame({
    "Customer ID": [201, 202, 201, 203, 202],
    "Product ID": ["P01", "P02", "P01", "P03", "P02"]
})
df7.to_excel("exercise3.xlsx", index=False)
