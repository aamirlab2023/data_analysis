# Data Validation

## Introduction

Data Validation is a feature in Excel that controls what users can enter into a cell. It prevents invalid data entry and enforces consistency.

- **Dropdown Lists:** Restrict input to a predefined list of values.

- **Numeric Ranges:** Allow only numbers within a specific range.

- **Date Restrictions:** Allow only dates within a set window.

## The Why Section

- To ensure data integrity.

- To reduce human error in data entry.

- To guide users on what type of input is expected.

- To streamline data analysis by enforcing standardization.

## Advantages

|Type | Advantages |
|:-----|:-----|
|Dropdown Lists | Easy and consistent data entry |
|Numeric Ranges | Prevents invalid numerical entries (e.g., negative prices) |
|Date Restrictions | Ensures relevant and valid date entries |

**Common Advantages:**

- Reduce data cleaning time.

- Help maintain data quality.

- Guide users during form or sheet filling.

## Practical

### (a) Normal Excel Way

1. **Dropdown Lists:**

    - Select cells > go to **Data** tab > click **Data Validation**.

    - Choose **List** > enter values separated by commas or reference a range.

    - Example: Red, Blue, Green or `=A1:A3`

2. **Numeric Ranges:**

    - Choose Whole Number or Decimal.

    - Set a minimum and maximum (e.g., between 1 and 100).

3. **Date Restrictions:**

    - Choose Date.

    - Set condition: e.g., between 1/1/2024 and 12/31/2024.

### (b) Power Query Way


Power Query does not support direct data validation like dropdowns or numeric limits in Excel sheets. However, it allows you to:

- Remove or flag invalid entries.

- Filter data that falls outside of desired ranges.

- Add logic to restrict rows (e.g., only dates after 2023).

## Examples

**Dropdown Lists**

1. Allow only entries: “Manager”, “Analyst”, “Clerk”.

2. List of departments: “HR”, “IT”, “Finance”.

**Numeric Ranges**

1. Allow quantities between 1 and 500.

2. Allow prices from $5.00 to $999.99.

**Date Restrictions**

1. Allow only birthdates after 1/1/1980 and before 1/1/2005.

2. Limit dates to this month only.

## Summary

Data Validation in Excel ensures only valid, expected data is entered. Subtypes like Dropdown Lists, Numeric Ranges, and Date Restrictions provide specific control over the format and range of inputs. These features improve data quality, reduce errors, and streamline analysis.

## Exercises

### Exercise 1: Dropdown

Create a list of valid cities ("New York", "Chicago", "Dallas") and restrict a column to only allow these via dropdown.

### Exercise 2: Numeric Range

Allow only quantities between 10 and 100 in a "Stock" column.

### Exercise 3: Date Restriction

Allow only dates between 2024-01-01 and 2024-12-31 in a "Delivery Date" column.
