# Math and Stats Functions

|Function|	Description|
|:-----|:-----|
|**SUM**|	Adds numbers.|
|**AVERAGE**|	Returns the arithmetic mean of numbers.|
|**MEDIAN**|	Returns the middle number in a list.|
|**COUNT**|	Counts numeric values.|
|**COUNTA**|	Counts non-empty cells (including text).|
|**COUNTIF**|	Counts cells based on one condition.|
|**COUNTIFS**|	Counts cells based on multiple conditions.|
|**SUMIF**|	Adds values based on one condition.|
|**SUMIFS**|	Adds values based on multiple conditions.|
|**MIN**|	Finds the smallest number.|
|**MAX**|	Finds the largest number.|
|**RANK**|	Shows the rank of a number within a list.|

## The Why Section

These functions are used to:

- Summarize and describe datasets.

- Analyze trends (averages, totals, ranks).

- Filter and aggregate data based on conditions.

- Support decision-making through statistical analysis.

## Advantages

- **Efficient Analysis:** Quickly calculate totals, averages, counts.

- **Conditional Aggregation:** Only summarize relevant data.

- **Ranking & Comparison:** Identify top performers or lowest values.

- **Data Quality:** Identify missing data with COUNT vs COUNTA.

## Practical

### (a) Normal Excel Interface

### 1. Insert Functions

- Go to **Formulas > Math & Trig** or **Statistical**.

- Or use **Insert Function (fx)** button.

### 2. Type Directly

- Example: `=SUM(A1:A10)` or `=AVERAGE(B1:B5)`

### (b) Power Query

1. Load data via **Data > Get & Transform Data > From Table/Range**.

2. Use **Transform > Statistics**:

    - Options like Sum, Average, Min, Max.

3. For COUNTIF/SUMIF:

    - Group data with **Group By**, then use filters and aggregations manually.

## Examples

|Function	|Formula Example|	Result|	Meaning|
|:-----|:-----|:-----:|:-----|
|**SUM**|	`=SUM(B2:B6)`	|250|	Adds all values in B2 to B6|
|**AVERAGE**|	`=AVERAGE(B2:B6)`	|50|	Calculates mean|
|**MEDIAN**|	`=MEDIAN(B2:B6`)	|50|	Returns the middle value|
|**COUNT**|	`=COUNT(B2:B6)`	|5|	Counts numbers only|
|**COUNTA**	|`=COUNTA(A2:A6)`	|5|	Counts all non-empty cells|
|**COUNTIF**|	`=COUNTIF(B2:B6, ">50")`	|2|	Counts values > 50|
|**COUNTIFS**|	`=COUNTIFS(A2:A6,"Sales",B2:B6,">50")`	|1|	Count with 2 conditions|
|**SUMIF**|	`=SUMIF(A2:A6,"Sales",B2:B6)`	|70|	Sum of B where A = Sales|
|**SUMIFS**|	`=SUMIFS(B2:B6, A2:A6,"Sales", C2:C6,">2020")`	|70|	Sum with 2 filters|
|**MIN**|	`=MIN(B2:B6)`	|30|	Smallest number
|**MAX**|	`=MAX(B2:B6)`	|70|	Largest number|
|**RANK**|	`=RANK(B2,B2:B6)`	|2|	Ranks B2 in range B2:B6|

## Summary

Math and stats functions are essential tools for summarizing and analyzing datasets. They help in calculating totals, averages, counts, rankings, and conditional aggregates. These functions are foundational for working with numeric data in business, finance, education, and beyond.

## Exercises

### Exercise 1: Sales Summary

- **Dataset:** Sales Amount

- **Task:** Use `SUM`, `AVERAGE`, `MAX`, `MIN` to summarize the data.

### Exercise 2: Attendance Count

- **Dataset:** Employee Attendance Status

- **Task:** Use `COUNT`, `COUNTA`, `COUNTIF` to count absences and presents.

### Exercise 3: Conditional Bonus Allocation

- **Dataset:** Employee Department, Year, and Bonus

- **Task:** Use `SUMIFS` to calculate total bonuses for Sales in 2023.