# Using Total Row for Quick Summaries

## Introduction

The Total Row in an Excel Table is a special row at the bottom that automatically calculates summary statistics such as:

- Sum

- Average

- Count

- Min/Max

It applies functions to each column and updates automatically as data changes.

## The Why Section

- To get quick insights without writing formulas manually.

- To summarize table columns efficiently.

- To dynamically update summaries as data changes or expands.

## Advantages

|Advantage | Description |
|:-----|:-----|
|Speed | Quickly applies summary stats without writing formulas |
|Accuracy | Reduces the risk of formula errors |
|Flexibility | Easily switch between sum, average, count, etc. |
|Dynamic | Auto-adjusts with table changes |

## Practical

### (a) Normal Excel Way

1. Click any cell in the Excel Table.

2. Go to the **Table Design** tab (called “**Table Tools**” in older versions).

3. Check the box for **Total Row**.

4. Click the cell in the Total Row under a column to choose the summary function (Sum, Average, etc.).

### (b) Power Query Way

1. Load your data using **Data → From Table/Range**.

2. In Power Query Editor:

    - Use the **Group By** feature (**Transform tab**).

    - Choose operation: Sum, Average, Count, etc.

3. Click **Close & Load** to bring the summarized data back to Excel.

**Note:** Power Query doesn't use a "Total Row" visually like Excel Tables. Instead, it uses transformations to summarize.

## Examples

|Sr. No. |Example | Description |
|:-----|:-----|:-----|
|1. | Sum Total Sales | Use the Total Row to sum all sales amounts. |
|2. | Average Age | Show average age in an HR table.|

**Note:** You can also apply Min, Max, and Count in the Total Row.

## Summary

The Total Row in Excel Tables allows users to quickly calculate and display summary statistics (like sum or average) without writing formulas. It's ideal for fast insights and adjusts dynamically as data changes. In Power Query, similar summaries can be created using "Group By".

## Exercises

### Exercise 1

Convert a data range into a Table and add a Total Row to calculate the total revenue.

### Exercise 2

In a product table, use the Total Row to show the average price and total stock.

### Exercise 3

In Power Query, load a dataset and summarize total sales by region using Group By.
