# Using Structured References

## Introduction

Structured references are a special way of referring to Excel Table data using column names rather than traditional cell addresses. They are used within Excel Tables only and make formulas more readable and dynamic.

For example:
Instead of `=A2+B2`, you'd write: `=[@Sales]+[@Tax]`

## The Why Section

- To make formulas easier to read and understand.

- To automatically update formulas when rows/columns are added or removed.

- To maintain consistency in dynamic tables.

## Advantages

|Feature | Benefit |
|:-----|:-----|
|Clarity | Uses column names instead of ambiguous cell references |
|Automatic Adjustment | Expands to include new rows automatically |
|Consistency | Eliminates errors when copying formulas down a table |
|Integration | Works well with Excel Tables, charts, and PivotTables |

## Practical

### (a) Normal Excel Way

1. Convert your data range into a **Table** (**Insert > Table or Ctrl + T**).

2. Click on a blank column and type a formula like:

    - `=[@Price]*[@Quantity]`

3. Excel automatically fills the column using structured references.

### (b) Power Query Way

1. Load data via **Data > From Table/Range**.

2. Add a custom column using **Add Column > Custom Column**.

3. While not using structured references directly, it uses column names inside formulas (like `=[Price]*[Quantity]`), which is similar.

## Examples

|Sr. No.  | Example | Formula |
|:-----|:-----|:-----|
|1. |Total Price | `=[@Quantity]*[@UnitPrice]` |
|2. |Profit Margin | `=[@Revenue] - [@Cost]` |

These automatically adjust to table size and structure.

## Summary

Structured references simplify formula writing by using column headers instead of cell addresses. They only work within Excel Tables and offer dynamic, scalable, and easy-to-read formulas. They improve accuracy, readability, and efficiency in data handling.

## Exercises

## Exercise 1

Create a Table of products with columns Price and Quantity, and calculate Total = Price * Quantity using structured references.

## Exercise 2

Add a Discount column and compute Final Price = Total - Discount.

## Exercise 3

Create a Table with Revenue and Cost, then calculate Profit = Revenue - Cost.
