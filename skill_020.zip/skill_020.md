# Using Flash Fill

## Introduction

Flash Fill is an Excel feature that automatically fills in values based on patterns it detects in your data. When you begin typing a value that follows a pattern based on adjacent cells, Flash Fill suggests the rest of the column for you.

**Example:**
If you have names in the format "John Doe" and start typing "John" in a new column, Flash Fill can extract the first names for the rest automatically.

## The Why Section

Flash Fill is used to:

- Split or combine text (e.g., first and last names).

- Reformat data (e.g., changing date or number formats).

- Clean up text (e.g., removing symbols).

- Automate repetitive data entry without writing formulas.

## Advantages

- No formulas required – just type and Excel handles the rest.

- Fast and intuitive.

- Great for non-technical users.

- Works well for one-time cleanups.

- Easy to undo if needed (Ctrl + Z).

## Practical

### (a) Normal Way (Manual Flash Fill)

1. Enter the desired value in the first cell based on a pattern (e.g., extract first name).

2. Go to the next cell and start typing the next value.

3. Excel may suggest a list (ghosted preview). Press Enter to accept.

4. Or, click **Data > Flash Fill**, or press **Ctrl + E**.

### (b) Power Query Way (More Manual but Flexible)

1. Select your data > **Data tab → From Table/Range**.

2. In Power Query Editor:

    - Use **Split Column** (by delimiter or number of characters).

    - Use **Add Column > Column From Examples** (similar to Flash Fill).

3. Click Close & Load to return to Excel.

## Examples

### Example 1: Extract First Names

|Full Name | First Name |
|:-----|:-----|
|John Doe | John |
|Jane Smith | Jane |
|Alice Johnson | Alice |

You type "John" next to "John Doe", press **Ctrl + E**, and Excel fills the rest.

### Example 2: Format Phone Numbers

|Raw Number | Formatted |
|:-----|:-----|
|1234567890 | (123) 456-7890 |
|9876543210 | (987) 654-3210 |

You type "(123) 456-7890", press **Ctrl + E**, Excel applies format to others.

## Summary

Flash Fill in Excel allows users to automatically fill in values based on patterns without using formulas. It is especially useful for tasks like splitting text, combining cells, formatting values, or extracting information. Flash Fill is available via the Ctrl + E shortcut or from the Data tab and works best for consistent patterns.

## Exercises

### Exercise 1: Extract Last Names

- **Column A:** Full Name (e.g., "Emily Carter")

- **Column B:** Use Flash Fill to extract the last names ("Carter").

### Exercise 2: Format Employee IDs

- **Column A:** Employee ID (e.g., "emp123")

- **Column B:** Format as "EMP-00123".

### Exercise 3: Combine Address Components

- **Columns:** Street, City, State

- **Combine into one formatted line using Flash Fill:** "123 Main St, Springfield, IL"
